"""Service-layer tests: the business rules from Phase 1 (FR/NFR) and Phase 2 (logic design)."""
import pytest

from app import config, db
from app.repositories import ProductRepository
from app.services import auth_service, cart_service, catalog_service, order_service
from app.services.cart_service import Cart
from app.services.errors import (AuthError, CartError, CatalogError, OrderError,
                                 StockError, ValidationError)

SHIP = {"name": "Test Buyer", "phone": "08031234567", "address": "5 Market Road, Yola",
        "payment_method": "card_transfer"}


def _ids():
    seller = auth_service.login("seller@solestride.com", "Seller@123")
    buyer = auth_service.login("buyer@solestride.com", "Buyer@123")
    return seller, buyer


# ---------- auth (FR-1, NFR-3) ----------
def test_password_is_hashed_never_plaintext(fresh_db):
    auth_service.register("Ada Obi", "ada@example.com", "S3cret-pass")
    with db.get_conn() as conn:
        stored = conn.execute("SELECT password_hash FROM users WHERE email='ada@example.com'").fetchone()[0]
    assert "S3cret-pass" not in stored and stored.startswith("pbkdf2_sha256$")


def test_same_password_gets_different_hashes(fresh_db):
    assert auth_service.hash_password("abcdefgh") != auth_service.hash_password("abcdefgh")


def test_login_ok_and_wrong_password(fresh_db):
    assert auth_service.login("SELLER@solestride.com ", "Seller@123").role == "seller"
    with pytest.raises(AuthError):
        auth_service.login("seller@solestride.com", "wrong-password")
    with pytest.raises(AuthError):  # unknown email -> same message (no account enumeration)
        auth_service.login("nobody@example.com", "whatever123")


@pytest.mark.parametrize("name,email,pw", [("A", "a@b.co", "longenough1"), ("Ada", "not-an-email", "longenough1"),
                                           ("Ada", "ada@b.co", "short")])
def test_register_validation(fresh_db, name, email, pw):
    with pytest.raises(ValidationError):
        auth_service.register(name, email, pw)


def test_duplicate_email_rejected(fresh_db):
    with pytest.raises(ValidationError):
        auth_service.register("Other", "buyer@solestride.com", "longenough1")


# ---------- catalog (FR-1, FR-2, FR-7) ----------
def test_search_category_and_size_filters(fresh_db):
    assert len(catalog_service.list_products()) == 8
    assert [p.name for p in catalog_service.list_products(query="loafer")] == ["Classic Loafer"]
    assert {p.category for p in catalog_service.list_products(category="Sandals")} == {"Sandals"}
    # Oxford Leather has no stock in EU 39, so a size-39 filter must exclude it
    assert "Oxford Leather" not in [p.name for p in catalog_service.list_products(size=39)]


def test_seller_can_create_edit_and_soft_delete(fresh_db):
    seller, _ = _ids()
    p = catalog_service.upsert_product(seller.id, {"name": "Test Shoe", "price": "15,000", "category": "Boots",
                                                    "sizes": {40: 3, 41: "4"}})
    assert p.price == 15000 and p.sizes == {40: 3, 41: 4}
    p2 = catalog_service.upsert_product(seller.id, {"name": "Test Shoe 2", "price": 16000, "category": "Boots",
                                                     "sizes": {40: 9}}, product_id=p.id)
    assert p2.name == "Test Shoe 2" and p2.sizes[40] == 9
    catalog_service.delete_product(seller.id, p.id)
    assert p.id not in [x.id for x in catalog_service.list_products()]


def test_seller_cannot_touch_another_sellers_listing(fresh_db):
    other = auth_service.register("Other Seller", "other@example.com", "longenough1", "seller")
    with pytest.raises(CatalogError):
        catalog_service.upsert_product(other.id, {"name": "Hijack", "price": 1, "category": "Boots"}, product_id=1)
    with pytest.raises(CatalogError):
        catalog_service.delete_product(other.id, 1)


@pytest.mark.parametrize("bad", [{"name": "", "price": 100, "category": "Boots"},
                                 {"name": "Shoe", "price": "abc", "category": "Boots"},
                                 {"name": "Shoe", "price": 0, "category": "Boots"},
                                 {"name": "Shoe", "price": 100, "category": "Hats"},
                                 {"name": "Shoe", "price": 100, "category": "Boots", "sizes": {40: -1}}])
def test_catalog_validation(fresh_db, bad):
    seller, _ = _ids()
    with pytest.raises(ValidationError):
        catalog_service.upsert_product(seller.id, bad)


def test_low_stock_indicator(fresh_db):
    seller, _ = _ids()
    low = {(p.name, s) for p, s, q in catalog_service.low_stock(seller.id)}
    assert ("Oxford Leather", 42) in low and ("Slide Sandal", 41) not in low


# ---------- cart (FR-3) ----------
def test_cart_total_is_sum_of_price_times_qty_plus_delivery(fresh_db):
    c = Cart()
    cart_service.add_item(c, 1, 42, 2)   # 28,500 x 2
    cart_service.add_item(c, 3, 40, 1)   # 9,800
    s = cart_service.summarize(c)
    assert s.subtotal == 28500 * 2 + 9800
    assert s.total == s.subtotal + config.DELIVERY_FEE and s.item_count == 3


def test_cart_requires_size_and_respects_stock(fresh_db):
    c = Cart()
    with pytest.raises(CartError):
        cart_service.add_item(c, 1, None, 1)
    with pytest.raises(CartError):
        cart_service.add_item(c, 2, 39, 1)       # Oxford EU39: sold out
    with pytest.raises(CartError):
        cart_service.add_item(c, 1, 45, 3)       # only 2 left
    cart_service.add_item(c, 1, 45, 2)
    with pytest.raises(CartError):
        cart_service.add_item(c, 1, 45, 1)       # would exceed stock


def test_cart_update_and_remove(fresh_db):
    c = Cart()
    cart_service.add_item(c, 3, 41, 1)
    cart_service.update_qty(c, 3, 41, 4)
    assert c.items[(3, 41)] == 4
    cart_service.update_qty(c, 3, 41, 0)
    assert not c.items
    cart_service.add_item(c, 3, 41, 1); cart_service.remove_item(c, 3, 41)
    assert len(c) == 0


# ---------- checkout (FR-4) ----------
def test_checkout_creates_order_and_decrements_only_that_size(fresh_db):
    _, buyer = _ids()
    before = catalog_service.get_product(1).sizes.copy()
    c = Cart(); cart_service.add_item(c, 1, 42, 2)
    order = order_service.checkout(buyer.id, c, SHIP)
    after = catalog_service.get_product(1).sizes
    assert order.reference.startswith("SS-") and order.status == "pending"
    assert order.total == 28500 * 2 + config.DELIVERY_FEE
    assert after[42] == before[42] - 2 and all(after[s] == before[s] for s in before if s != 42)


def test_unit_price_is_a_snapshot(fresh_db):
    seller, buyer = _ids()
    c = Cart(); cart_service.add_item(c, 3, 41, 1)
    order = order_service.checkout(buyer.id, c, SHIP)
    catalog_service.upsert_product(seller.id, {"name": "Slide Sandal", "price": 99999, "category": "Sandals"}, product_id=3)
    mine = [o for o in order_service.list_for_buyer(buyer.id) if o.id == order.id][0]
    assert mine.items[0].unit_price == 9800


def test_checkout_rejects_oversell_and_writes_nothing(fresh_db):
    _, buyer = _ids()
    c = Cart(); cart_service.add_item(c, 1, 45, 2)
    # someone else buys the last pairs first
    other = Cart(); cart_service.add_item(other, 1, 45, 2)
    order_service.checkout(buyer.id, other, SHIP)
    orders_before = len(order_service.list_for_buyer(buyer.id))
    with pytest.raises(StockError) as err:
        order_service.checkout(buyer.id, c, SHIP)
    assert "sold out" in str(err.value)
    assert len(order_service.list_for_buyer(buyer.id)) == orders_before
    assert catalog_service.get_product(1).sizes[45] == 0


def test_failed_checkout_is_all_or_nothing(fresh_db):
    _, buyer = _ids()
    c = Cart(); cart_service.add_item(c, 3, 41, 1); cart_service.add_item(c, 1, 45, 2)
    other = Cart(); cart_service.add_item(other, 1, 45, 2)
    order_service.checkout(buyer.id, other, SHIP)
    stock_before = catalog_service.get_product(3).sizes[41]
    with pytest.raises(StockError):
        order_service.checkout(buyer.id, c, SHIP)
    assert catalog_service.get_product(3).sizes[41] == stock_before   # the good line was not charged


@pytest.mark.parametrize("field,value", [("name", ""), ("phone", "123"), ("address", "x"), ("payment_method", "bitcoin")])
def test_checkout_validates_form(fresh_db, field, value):
    _, buyer = _ids()
    c = Cart(); cart_service.add_item(c, 3, 41, 1)
    with pytest.raises(ValidationError):
        order_service.checkout(buyer.id, c, {**SHIP, field: value})


def test_empty_cart_cannot_checkout(fresh_db):
    _, buyer = _ids()
    with pytest.raises(OrderError):
        order_service.checkout(buyer.id, Cart(), SHIP)


# ---------- order workflow (FR-5, FR-6) ----------
def test_status_moves_forward_only(fresh_db):
    seller, buyer = _ids()
    oid = order_service.list_for_buyer(buyer.id)[0].id   # seeded pending order
    assert order_service.update_status(seller.id, oid, "shipped").status == "shipped"
    with pytest.raises(OrderError):
        order_service.update_status(seller.id, oid, "pending")      # no going back
    with pytest.raises(OrderError):
        order_service.update_status(seller.id, oid, "cancelled")    # cancel only from pending
    assert order_service.update_status(seller.id, oid, "delivered").status == "delivered"
    with pytest.raises(OrderError):
        order_service.update_status(seller.id, oid, "shipped")


def test_cancel_pending_order_restocks(fresh_db):
    seller, buyer = _ids()
    c = Cart(); cart_service.add_item(c, 3, 41, 2)
    before = catalog_service.get_product(3).sizes[41]
    order = order_service.checkout(buyer.id, c, SHIP)
    assert catalog_service.get_product(3).sizes[41] == before - 2
    order_service.update_status(seller.id, order.id, "cancelled")
    assert catalog_service.get_product(3).sizes[41] == before


def test_other_seller_cannot_update_order_and_buyer_sees_status(fresh_db):
    other = auth_service.register("Other Seller", "other@example.com", "longenough1", "seller")
    seller, buyer = _ids()
    oid = order_service.list_for_buyer(buyer.id)[0].id
    with pytest.raises(OrderError):
        order_service.update_status(other.id, oid, "shipped")
    order_service.update_status(seller.id, oid, "shipped")
    o = order_service.list_for_buyer(buyer.id)[0]
    assert o.status == "shipped" and "on its way" in order_service.STATUS_MESSAGES[o.status]
    assert order_service.list_for_seller(other.id) == []
