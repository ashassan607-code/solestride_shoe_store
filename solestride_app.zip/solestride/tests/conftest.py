import pytest

from app import config, db


@pytest.fixture()
def fresh_db(tmp_path, monkeypatch):
    """Isolated, seeded database per test."""
    monkeypatch.setattr(config, "DB_PATH", tmp_path / "test.db")
    monkeypatch.setattr(config, "ALLOW_SELLER_SIGNUP", True)
    monkeypatch.setattr(config, "SEED_DEMO", True)
    monkeypatch.setattr(config, "PBKDF2_ITERATIONS", 1000)  # fast hashing in tests only
    db.init_db(seed=True)
    return tmp_path
