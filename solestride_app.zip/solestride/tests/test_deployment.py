"""Phase 5 checks: production safety (risks R-01, R-05), operator tools and deployment files."""
import os
import re
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest

from app import admin, config, db
from app.services import auth_service
from app.services.errors import AuthError, ValidationError

ROOT = Path(__file__).resolve().parent.parent


# ------------------------------------------------ login throttling (R-01)
def test_account_locks_after_repeated_failures_even_with_correct_password(fresh_db):
    for _ in range(config.LOGIN_MAX_FAILURES):
        with pytest.raises(AuthError):
            auth_service.login("buyer@solestride.com", "wrong-password")
    with pytest.raises(AuthError) as err:
        auth_service.login("buyer@solestride.com", "Buyer@123")
    assert "Too many failed attempts" in str(err.value)


def test_lockout_message_is_identical_for_unknown_emails(fresh_db):
    for _ in range(config.LOGIN_MAX_FAILURES):
        with pytest.raises(AuthError):
            auth_service.login("ghost@example.com", "whatever123")
    with pytest.raises(AuthError) as err:
        auth_service.login("ghost@example.com", "whatever123")
    assert "Too many failed attempts" in str(err.value)      # same behaviour as a real account


def test_successful_login_resets_the_counter(fresh_db):
    for _ in range(config.LOGIN_MAX_FAILURES - 1):
        with pytest.raises(AuthError):
            auth_service.login("buyer@solestride.com", "wrong-password")
    assert auth_service.login("buyer@solestride.com", "Buyer@123").role == "buyer"
    for _ in range(config.LOGIN_MAX_FAILURES - 1):             # fresh allowance
        with pytest.raises(AuthError):
            auth_service.login("buyer@solestride.com", "wrong-password")
    assert auth_service.login("buyer@solestride.com", "Buyer@123")


def test_lockout_expires(fresh_db):
    for _ in range(config.LOGIN_MAX_FAILURES):
        with pytest.raises(AuthError):
            auth_service.login("buyer@solestride.com", "wrong-password")
    with db.get_conn() as conn:
        conn.execute("UPDATE login_failures SET attempted_at = datetime('now', '-20 minutes')")
    assert auth_service.login("buyer@solestride.com", "Buyer@123")


def test_failures_for_one_account_do_not_lock_another(fresh_db):
    for _ in range(config.LOGIN_MAX_FAILURES):
        with pytest.raises(AuthError):
            auth_service.login("buyer@solestride.com", "wrong-password")
    assert auth_service.login("seller@solestride.com", "Seller@123")


# ------------------------------------- production defaults (R-05) and seeding
def _config_in(env):
    code = "from app import config; print(config.IS_PRODUCTION, config.SEED_DEMO, config.ALLOW_SELLER_SIGNUP)"
    out = subprocess.run([sys.executable, "-c", code], cwd=ROOT, capture_output=True, text=True,
                         env={**{k: v for k, v in os.environ.items() if not k.startswith("SOLESTRIDE_")}, **env})
    assert out.returncode == 0, out.stderr
    return out.stdout.split()


def test_production_defaults_are_safe():
    assert _config_in({"SOLESTRIDE_ENV": "production"}) == ["True", "False", "False"]


def test_development_defaults_keep_demo_conveniences():
    assert _config_in({}) == ["False", "True", "True"]


def test_flags_can_be_overridden_by_environment():
    assert _config_in({"SOLESTRIDE_ENV": "production", "SOLESTRIDE_ALLOW_SELLER_SIGNUP": "1"})[2] == "True"


def test_no_demo_data_when_seeding_disabled(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "DB_PATH", tmp_path / "prod.db")
    monkeypatch.setattr(config, "SEED_DEMO", False)
    db.init_db()                                              # seed=None -> follows config
    with db.get_conn() as conn:
        assert conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0
        assert conn.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0


def test_seller_self_signup_blocked_in_production(fresh_db, monkeypatch):
    monkeypatch.setattr(config, "ALLOW_SELLER_SIGNUP", False)
    with pytest.raises(ValidationError):
        auth_service.register("Mallory", "mallory@example.com", "longenough1", role="seller")
    assert auth_service.register("Bola Buyer", "bola@example.com", "longenough1", role="buyer").role == "buyer"


# ------------------------------------------------------------ operator tools
def test_owner_can_be_created_by_admin_command_in_a_fresh_production_db(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "DB_PATH", tmp_path / "prod.db")
    monkeypatch.setattr(config, "ALLOW_SELLER_SIGNUP", False)
    monkeypatch.setattr(config, "PBKDF2_ITERATIONS", 1000)
    owner = admin.create_seller("Store Owner", "owner@example.com", "a-strong-passphrase")
    assert owner.role == "seller"
    assert auth_service.login("owner@example.com", "a-strong-passphrase").is_seller


def test_backup_is_a_complete_usable_copy(fresh_db, tmp_path):
    target = admin.backup(tmp_path / "bk")
    assert target.exists() and target.suffix == ".db"
    copy = sqlite3.connect(target)
    try:
        assert copy.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 2
        assert copy.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 8
    finally:
        copy.close()


# --------------------------------------------------------- deployment files
def _read(name):
    return (ROOT / name).read_text()


def test_dockerfile_basics():
    d = _read("Dockerfile")
    assert re.search(r"^FROM python:3\.12", d, re.M)
    assert "USER app" in d and "HEALTHCHECK" in d and "EXPOSE 8000" in d
    assert "SOLESTRIDE_ENV=production" in d and "FLET_FORCE_WEB_SERVER=true" in d


def test_production_requirements_are_pinned():
    lines = [l for l in _read("requirements-prod.txt").splitlines() if l.strip() and not l.startswith("#")]
    assert lines and all("==" in l for l in lines)
    assert any(l.startswith("flet-web") for l in lines)


def test_secrets_and_data_stay_out_of_git_and_images():
    assert ".env" in _read(".gitignore").splitlines() and "data/*.db" in _read(".gitignore")
    ignore = _read(".dockerignore")
    assert all(x in ignore for x in (".git", ".env", "data/"))


def test_env_example_contains_no_secrets():
    text = _read(".env.example").lower()
    assert not re.search(r"(password|secret|token|api_key)\s*=\s*\S+", text)


def test_compose_persists_data_and_hides_app_port():
    c = _read("docker-compose.yml")
    assert "solestride-data:/data" in c and "expose:" in c
    assert not re.search(r'^\s*-\s*"8000:8000"', c, re.M)      # app port is not published to the internet
