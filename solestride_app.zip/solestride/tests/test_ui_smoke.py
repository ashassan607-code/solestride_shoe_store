"""UI smoke tests.

Flet controls validate their arguments when they are constructed, so building
every screen against a stand-in page catches API misuse without a display.
The tests also walk the control tree and fire real button handlers.
"""
import asyncio
import dataclasses

import flet as ft
import pytest

from app.ui.app import SoleStrideApp


class FakePage:
    def __init__(self):
        self.controls, self.dialogs = [], []
        self.window = type("W", (), {})()

    def clean(self): self.controls = []
    def add(self, *c): self.controls.extend(c)
    def update(self, *a): pass
    def show_dialog(self, d): self.dialogs.append(d)
    def pop_dialog(self): return self.dialogs.pop() if self.dialogs else None


def walk(node, seen=None):
    seen = seen if seen is not None else set()
    if id(node) in seen:
        return
    seen.add(id(node))
    yield node
    if dataclasses.is_dataclass(node):
        for f in dataclasses.fields(node):
            v = getattr(node, f.name, None)
            items = v if isinstance(v, (list, tuple)) else [v]
            for it in items:
                if isinstance(it, ft.BaseControl):
                    yield from walk(it, seen)


def texts(root):
    out = []
    for n in walk(root):
        for attr in ("value", "content", "label", "text"):
            v = getattr(n, attr, None)
            if isinstance(v, str):
                out.append(v)
    return out


def find_button(root, label):
    for n in walk(root):
        if isinstance(n, (ft.Button, ft.TextButton, ft.OutlinedButton)):
            c = getattr(n, "content", None)
            if c == label or getattr(n, "text", None) == label:
                return n
    raise AssertionError(f"button {label!r} not found")


def find_field(root, label):
    for n in walk(root):
        if isinstance(n, (ft.TextField, ft.Dropdown)) and getattr(n, "label", None) == label:
            return n
    raise AssertionError(f"field {label!r} not found")


def click(btn):
    r = btn.on_click(None)
    if asyncio.iscoroutine(r):
        asyncio.run(r)


@pytest.fixture()
def app(fresh_db):
    a = SoleStrideApp(FakePage())
    a.start()
    return a


def body(app):
    return app.page.controls[1]


def test_every_route_builds(app):
    app.go("detail", product_id=1, size=None, qty=1)
    app.go("detail", product_id=1, size=42, qty=2)
    app.go("cart"); app.go("login", mode="login"); app.go("login", mode="register")
    assert "Create your account" in texts(body(app))
    app.go("home")
    assert any("Classic Runner" in t for t in texts(body(app)))


def test_home_lists_all_demo_shoes_and_filters(app):
    names = texts(body(app))
    for n in ["Classic Runner", "Oxford Leather", "Slide Sandal", "Chelsea Boot", "Strap Sandal"]:
        assert n in names
    app.filters["category"] = "Sandals"; app.render()
    names = texts(body(app))
    assert "Slide Sandal" in names and "Classic Runner" not in names


def test_buyer_flow_login_cart_checkout_and_order_history(app):
    # pick a size and add to cart
    app.go("detail", product_id=1, size=42, qty=2)
    click(find_button(body(app), "Add to Cart"))
    assert len(app.cart) == 2
    app.go("cart")
    assert "Order Summary" in texts(body(app)) and "\u20a657,000" in texts(body(app))
    # checkout while logged out -> sent to login with next=checkout
    app.go("checkout")
    assert app.route == "login" and app.params["next"] == "checkout"
    find_field(body(app), "Email").value = "buyer@solestride.com"
    find_field(body(app), "Password").value = "Buyer@123"
    click(find_button(body(app), "Log in"))
    assert app.user and app.route == "checkout"
    # invalid form shows an error, does not crash
    click(find_button(body(app), "Place Order"))
    assert any("phone" in t.lower() for t in texts(body(app)))
    find_field(body(app), "Phone number").value = "08031234567"
    find_field(body(app), "Delivery address").value = "7 Shopping Complex Road, Yola"
    click(find_button(body(app), "Place Order"))
    assert app.route == "order_done" and len(app.cart) == 0
    assert any(t.startswith("Your order ID is SS-") for t in texts(body(app)))
    app.go("orders")
    assert "PENDING" in texts(body(app))


def test_seller_dashboard_tabs_and_status_update(app):
    app.go("seller", tab="products")           # logged out -> login
    assert app.route == "login"
    find_field(body(app), "Email").value = "seller@solestride.com"
    find_field(body(app), "Password").value = "Seller@123"
    click(find_button(body(app), "Log in"))
    assert app.route == "seller"
    assert "Classic Runner" in texts(body(app))
    app.go("seller", tab="stock")
    assert any("running low" in t for t in texts(body(app)))
    app.go("seller", tab="orders")
    click(find_button(body(app), "Mark as shipped"))
    assert "SHIPPED" in texts(body(app))
    click(find_button(body(app), "Mark as delivered"))
    assert "DELIVERED" in texts(body(app))


def test_seller_add_product_dialog(app):
    from app.services import auth_service, catalog_service
    app.user = auth_service.login("seller@solestride.com", "Seller@123")
    app.go("seller", tab="products")
    click(find_button(body(app), "+ Add Product"))
    dlg = app.page.dialogs[-1]
    find_field(dlg, "Shoe name").value = "Test Derby"
    find_field(dlg, "Price (\u20a6)").value = "36000"
    find_field(dlg, "Category").value = "Formal"
    find_field(dlg, "EU 42").value = "6"
    click(find_button(dlg, "Save"))
    assert "Test Derby" in [p.name for p in catalog_service.list_products()]


def test_unknown_service_failure_shows_friendly_error(app, monkeypatch):
    from app.services import catalog_service
    monkeypatch.setattr(catalog_service, "list_products", lambda *a, **k: 1 / 0)
    app.go("home")
    assert "Something went wrong. Please try again." in texts(body(app))
