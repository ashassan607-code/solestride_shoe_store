"""Alpha test extension (Phase 4): security, concurrency, boundary and NFR checks."""
import logging
import threading
import time

import pytest

from app import config, db
from app.services import auth_service, cart_service, catalog_service, order_service
from app.services.cart_service import Cart
from app.services.errors import CartError, ServiceError, StockError, ValidationError

SHIP = {"name": "Test Buyer", "phone": "08031234567", "address": "5 Market Road, Yola",
        "payment_method": "card_transfer"}


def _buyer():
    return auth_service.login("buyer@solestride.com", "Buyer@123")


def _seller():
    return auth_service.login("seller@solestride.com", "Seller@123")


# ---------------------------------------------------------- security (NFR-3)
@pytest.mark.parametrize("payload", ["' OR '1'='1", "'; DROP TABLE users; --", "\" OR \"\"=\"", "x' UNION SELECT * FROM users --"])
def test_sql_injection_in_search_and_login_is_inert(fresh_db, payload):
    assert catalog_service.list_products(query=payload) == []          # treated as plain text
    with pytest.raises(ServiceError):
        auth_service.login(payload, payload)
    with db.get_conn() as conn:                                         # tables intact
        assert conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 2


def test_markup_in_user_text_is_stored_literally(fresh_db):
    seller = _seller()
    p = catalog_service.upsert_product(seller.id, {"name": "<script>alert(1)</script>", "price": 1000,
                                                    "category": "Boots", "sizes": {40: 1}})
    assert catalog_service.get_product(p.id).name == "<script>alert(1)</script>"


def test_passwords_never_reach_the_logs(fresh_db, caplog):
    with caplog.at_level(logging.DEBUG):
        auth_service.register("Log Tester", "log@example.com", "Sup3r-secret-pw")
        try:
            auth_service.login("log@example.com", "Wrong-secret-pw")
        except ServiceError:
            pass
    assert "Sup3r-secret-pw" not in caplog.text and "Wrong-secret-pw" not in caplog.text


def test_tampered_or_malformed_hash_fails_closed(fresh_db):
    assert not auth_service.verify_password("x", "garbage")
    assert not auth_service.verify_password("x", "md5$1$00$00")
    assert not auth_service.verify_password("x", "pbkdf2_sha256$notanumber$00$00")


def test_buyer_cannot_use_seller_actions(fresh_db):
    buyer = _buyer()
    with pytest.raises(ServiceError):
        catalog_service.upsert_product(buyer.id, {"name": "Hack", "price": 1, "category": "Boots"}, product_id=1)
    oid = order_service.list_for_buyer(buyer.id)[0].id
    with pytest.raises(ServiceError):
        order_service.update_status(buyer.id, oid, "shipped")


# ----------------------------------------------------- concurrency (checkout)
def test_two_threads_buying_the_last_pair_only_one_wins(fresh_db):
    buyer = _buyer()
    # Court Sneaker (id 4) EU 39 has 3 pairs; set to exactly 1
    catalog_service.upsert_product(_seller().id, {"name": "Court Sneaker", "price": 32000, "category": "Sneakers",
                                                   "sizes": {39: 1}}, product_id=4)
    results, barrier = [], threading.Barrier(6)

    def attempt():
        c = Cart(); cart_service.add_item(c, 4, 39, 1)
        barrier.wait()
        try:
            order_service.checkout(buyer.id, c, SHIP); results.append("ok")
        except StockError:
            results.append("sold-out")
        except Exception as e:                      # any other failure is a defect
            results.append(f"ERR {type(e).__name__}: {e}")

    threads = [threading.Thread(target=attempt) for _ in range(6)]
    [t.start() for t in threads]; [t.join() for t in threads]
    assert results.count("ok") == 1, results
    assert results.count("sold-out") == 5, results
    assert catalog_service.get_product(4).sizes[39] == 0


def test_stock_never_goes_negative_under_parallel_load(fresh_db):
    buyer = _buyer()
    start = catalog_service.get_product(3).sizes[41]       # Slide Sandal EU 41
    results = []

    def attempt():
        c = Cart()
        try:
            cart_service.add_item(c, 3, 41, 2)          # refused once fewer than 2 pairs remain
            order_service.checkout(buyer.id, c, SHIP); results.append(1)
        except (CartError, StockError):
            results.append(0)

    threads = [threading.Thread(target=attempt) for _ in range(12)]
    [t.start() for t in threads]; [t.join() for t in threads]
    left = catalog_service.get_product(3).sizes[41]
    assert left >= 0 and left == start - 2 * sum(results)


# ------------------------------------------------------------ boundaries
def test_search_wildcards_are_literal(fresh_db):
    assert catalog_service.list_products(query="%") == []
    assert catalog_service.list_products(query="_") == []


@pytest.mark.parametrize("field,value", [pytest.param("name", "A" * 500, id="long-name"), pytest.param("description", "D" * 5000, id="long-description")])
def test_oversized_listing_text_rejected(fresh_db, field, value):
    data = {"name": "Shoe", "price": 100, "category": "Boots", "description": "", field: value}
    with pytest.raises(ValidationError):
        catalog_service.upsert_product(_seller().id, data)


@pytest.mark.parametrize("name,email", [pytest.param("N" * 300, "a@b.co", id="long-name"), pytest.param("Ada", "a" * 300 + "@b.co", id="long-email")])
def test_oversized_registration_fields_rejected(fresh_db, name, email):
    with pytest.raises(ValidationError):
        auth_service.register(name, email, "longenough1")


def test_absurd_price_and_stock_rejected(fresh_db):
    seller = _seller()
    with pytest.raises(ValidationError):
        catalog_service.upsert_product(seller.id, {"name": "Gold", "price": 10 ** 12, "category": "Boots"})
    with pytest.raises(ValidationError):
        catalog_service.upsert_product(seller.id, {"name": "Gold", "price": 100, "category": "Boots", "sizes": {40: 10 ** 7}})


def test_cart_badge_count_ignores_removed_listings(fresh_db):
    c = Cart(); cart_service.add_item(c, 3, 41, 1)
    catalog_service.delete_product(_seller().id, 3)
    assert cart_service.summarize(c).lines == []
    order_service_error = None
    try:
        order_service.checkout(_buyer().id, c, SHIP)
    except ServiceError as e:
        order_service_error = e
    assert order_service_error is not None


def test_price_change_after_adding_to_cart_uses_new_price(fresh_db):
    c = Cart(); cart_service.add_item(c, 3, 41, 1)
    catalog_service.upsert_product(_seller().id, {"name": "Slide Sandal", "price": 11000, "category": "Sandals"}, product_id=3)
    assert cart_service.summarize(c).subtotal == 11000
    order = order_service.checkout(_buyer().id, c, SHIP)
    assert order.total == 11000 + config.DELIVERY_FEE


def test_restock_after_sell_out_allows_purchase(fresh_db):
    catalog_service.upsert_product(_seller().id, {"name": "Chelsea Boot", "price": 52500, "category": "Boots",
                                                   "sizes": {45: 0}}, product_id=5)
    c = Cart()
    with pytest.raises(ServiceError):
        cart_service.add_item(c, 5, 45, 1)
    catalog_service.upsert_product(_seller().id, {"name": "Chelsea Boot", "price": 52500, "category": "Boots",
                                                   "sizes": {45: 3}}, product_id=5)
    cart_service.add_item(c, 5, 45, 1)


def test_international_phone_formats_accepted(fresh_db):
    for phone in ["08031234567", "+234 803 123 4567", "0803-123-4567"]:
        c = Cart(); cart_service.add_item(c, 3, 40, 1)
        order_service.checkout(_buyer().id, c, {**SHIP, "phone": phone})


# --------------------------------------------------------------- NFR-1 / data
def test_nfr1_login_and_checkout_under_two_seconds(fresh_db, monkeypatch):
    monkeypatch.setattr(config, "PBKDF2_ITERATIONS", 200_000)     # production-strength hashing
    u = auth_service.register("Perf User", "perf@example.com", "longenough1")
    t0 = time.perf_counter(); auth_service.login("perf@example.com", "longenough1"); login_s = time.perf_counter() - t0
    c = Cart(); cart_service.add_item(c, 1, 42, 2); cart_service.add_item(c, 3, 41, 1)
    t0 = time.perf_counter(); order_service.checkout(u.id, c, SHIP); checkout_s = time.perf_counter() - t0
    assert login_s < 2.0 and checkout_s < 2.0, (login_s, checkout_s)


def test_order_ids_are_unique_and_retrievable(fresh_db):
    buyer = _buyer(); refs = set()
    for _ in range(5):
        c = Cart(); cart_service.add_item(c, 3, 40, 1)
        refs.add(order_service.checkout(buyer.id, c, SHIP).reference)
    assert len(refs) == 5
    mine = {o.reference for o in order_service.list_for_buyer(buyer.id)}
    assert refs <= mine


def test_data_is_minimal_no_card_fields_exist(fresh_db):
    with db.get_conn() as conn:
        cols = {r[1].lower() for t in ("users", "orders", "order_items") for r in conn.execute(f"PRAGMA table_info({t})")}
    assert not {c for c in cols if any(k in c for k in ("card", "cvv", "pan", "token"))}


def test_seed_is_idempotent(fresh_db):
    db.init_db(seed=True); db.init_db(seed=True)
    assert len(catalog_service.list_products()) == 8


def test_oversized_delivery_fields_rejected(fresh_db):
    for field in ("name", "address"):
        c = Cart(); cart_service.add_item(c, 3, 40, 1)
        with pytest.raises(ValidationError):
            order_service.checkout(_buyer().id, c, {**SHIP, field: "X" * 400})


def test_oversized_password_rejected_at_register_and_login(fresh_db):
    with pytest.raises(ValidationError):
        auth_service.register("Ada Obi", "ada@example.com", "p" * 500)
    with pytest.raises(ServiceError):
        auth_service.login("buyer@solestride.com", "p" * 500)
