"""Operator commands.

  python manage.py create-seller --name "Store Owner" --email owner@example.com
  python manage.py backup --to /data/backups
"""
import argparse
import getpass
import sys

from app import admin
from app.services.errors import ServiceError


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="SoleStride operator commands")
    sub = parser.add_subparsers(dest="command", required=True)
    cs = sub.add_parser("create-seller", help="create a seller (store owner) account")
    cs.add_argument("--name", required=True)
    cs.add_argument("--email", required=True)
    bk = sub.add_parser("backup", help="copy the database to a timestamped file")
    bk.add_argument("--to", default="backups", help="destination folder (default: ./backups)")
    args = parser.parse_args(argv)

    if args.command == "create-seller":
        password = getpass.getpass("Password (not shown): ")
        if password != getpass.getpass("Repeat password: "):
            print("Passwords do not match.")
            return 1
        try:
            user = admin.create_seller(args.name, args.email, password)
        except ServiceError as exc:
            print(f"Could not create account: {exc}")
            return 1
        print(f"Seller account created for {user.email}.")
    elif args.command == "backup":
        print(f"Backup written to {admin.backup(args.to)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
