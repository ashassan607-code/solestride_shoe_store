# SoleStride - Online Shoe Store (MVP)

Phase 3 (Development) deliverable for the AI-augmented SDLC coursework.
A single-codebase Python app built with [Flet](https://flet.dev) 1.0: buyers browse shoes,
pick an EU size, fill a cart and check out; sellers manage listings, per-size stock and orders.

## Run it
```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python main.py                  # desktop window
flet run --web main.py          # or in the browser
```
The SQLite database and demo data are created automatically on first run (`data/solestride.db`).

| Role   | Email                   | Password   |
|--------|-------------------------|------------|
| Seller | seller@solestride.com   | Seller@123 |
| Buyer  | buyer@solestride.com    | Buyer@123  |

Demo credentials are for the MVP only. Remove the seed and the login hint before any live deployment.

## Tests
```bash
pip install -r requirements-dev.txt
python -m pytest -q
```

## Layout
```
main.py                 entry point
app/config.py           constants (currency, sizes, delivery fee, status rules)
app/db.py, seed.py      SQLite schema + demo data
app/repositories.py     data access layer (all SQL lives here)
app/services/           business rules: auth, catalog, cart, order
app/ui/                 Flet front end: theme, components, views/
assets/                 logo + shoe images
tests/                  service tests + UI smoke tests
```

## Deploy
See [DEPLOYMENT.md](DEPLOYMENT.md) (Docker + automatic HTTPS). Production mode: `SOLESTRIDE_ENV=production`.
Operator commands: `python manage.py create-seller` and `python manage.py backup`.
