"""SoleStride - entry point.

  Desktop (development):   python main.py
  Browser  (development):  flet run --web main.py
  Production (Docker):     FLET_FORCE_WEB_SERVER=true FLET_SERVER_PORT=8000 python main.py
"""
import logging

import flet as ft

from app import config, db
from app.ui.app import SoleStrideApp

log = logging.getLogger("solestride")


def main(page: ft.Page) -> None:
    db.init_db()                      # idempotent; demo data only if SOLESTRIDE_SEED_DEMO allows it
    SoleStrideApp(page).start()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    log.info("Starting %s in %s mode (database: %s)", config.APP_NAME, config.ENV, config.DB_PATH)
    db.init_db()                      # create the database at startup, not on the first visit
    ft.run(main, assets_dir=str(config.ASSETS_DIR))
