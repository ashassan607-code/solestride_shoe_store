"""Shoe catalog: browse/search (FR-2), seller CRUD (FR-1), stock levels (FR-7)."""
from __future__ import annotations

from typing import Optional

from .. import config, db
from ..models import Product
from ..repositories import ProductRepository
from .errors import CatalogError, ValidationError


def list_products(query: str = "", category: str = "", size: Optional[int] = None,
                  seller_id: Optional[int] = None, include_inactive: bool = False) -> list[Product]:
    with db.get_conn() as conn:
        return ProductRepository(conn).list(
            query=(query or "").strip(), category=category if category in config.CATEGORIES else "",
            size=size, seller_id=seller_id, include_inactive=include_inactive,
        )


def get_product(product_id: int) -> Optional[Product]:
    with db.get_conn() as conn:
        return ProductRepository(conn).get(product_id)


def _clean(data: dict) -> dict:
    name = (data.get("name") or "").strip()
    if len(name) < 2 or len(name) > config.MAX_NAME_LEN:
        raise ValidationError(f"Shoe name is required (up to {config.MAX_NAME_LEN} characters).")
    description = (data.get("description") or "").strip()
    if len(description) > config.MAX_DESCRIPTION_LEN:
        raise ValidationError(f"Description is too long (maximum {config.MAX_DESCRIPTION_LEN} characters).")
    try:
        price = int(str(data.get("price", "")).replace(",", "").strip())
    except ValueError:
        raise ValidationError("Price must be a whole number of naira.")
    if price <= 0 or price > config.MAX_PRICE:
        raise ValidationError(f"Price must be between 1 and {config.MAX_PRICE:,} naira.")
    category = data.get("category")
    if category not in config.CATEGORIES:
        raise ValidationError("Please choose a category.")
    sizes: dict[int, int] = {}
    for size, qty in (data.get("sizes") or {}).items():
        size = int(size)
        if size not in config.SIZES:
            raise ValidationError(f"Size {size} is not offered.")
        try:
            qty = int(str(qty).strip() or 0)
        except ValueError:
            raise ValidationError(f"Stock for size {size} must be a whole number.")
        if qty < 0 or qty > config.MAX_STOCK_PER_SIZE:
            raise ValidationError(f"Stock for size {size} must be between 0 and {config.MAX_STOCK_PER_SIZE:,}.")
        sizes[size] = qty
    return {
        "name": name, "description": description, "price": price,
        "category": category, "image_path": data.get("image_path") or "", "sizes": sizes,
    }


def upsert_product(seller_id: int, data: dict, product_id: Optional[int] = None) -> Product:
    clean = _clean(data)
    with db.get_conn() as conn:
        repo = ProductRepository(conn)
        if product_id is None:
            product_id = repo.insert(seller_id, clean["name"], clean["description"], clean["price"],
                                     clean["category"], clean["image_path"])
        else:
            existing = repo.get(product_id)
            if not existing or existing.seller_id != seller_id:
                raise CatalogError("You can only edit your own listings.")
            repo.update(product_id, clean["name"], clean["description"], clean["price"],
                        clean["category"], clean["image_path"])
        for size, qty in clean["sizes"].items():
            repo.set_size_stock(product_id, size, qty)
        return repo.get(product_id)


def delete_product(seller_id: int, product_id: int) -> None:
    """Soft delete: past orders keep referencing the product."""
    with db.get_conn() as conn:
        repo = ProductRepository(conn)
        existing = repo.get(product_id)
        if not existing or existing.seller_id != seller_id:
            raise CatalogError("You can only delete your own listings.")
        repo.set_active(product_id, False)


def low_stock(seller_id: int) -> list[tuple[Product, int, int]]:
    """(product, size, qty) for every size at or below the low-stock threshold."""
    out = []
    for p in list_products(seller_id=seller_id):
        for size, qty in p.sizes.items():
            if qty <= config.LOW_STOCK_THRESHOLD:
                out.append((p, size, qty))
    return out
