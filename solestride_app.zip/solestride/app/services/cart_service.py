"""In-session shopping cart (FR-3).

The cart only remembers (product_id, size, quantity). Prices and stock are
always read live from the catalog, so the displayed total can never drift
from the real price. The same total is re-validated at checkout.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .. import config
from ..models import CartLine, CartSummary
from . import catalog_service
from .errors import CartError


@dataclass
class Cart:
    items: dict[tuple[int, int], int] = field(default_factory=dict)  # (product_id, size) -> qty

    def clear(self) -> None:
        self.items.clear()

    def __len__(self) -> int:
        return sum(self.items.values())


def _check(product_id: int, size: int, qty: int):
    product = catalog_service.get_product(product_id)
    if not product or not product.is_active:
        raise CartError("This shoe is no longer available.")
    if size not in product.sizes:
        raise CartError("Please choose a size.")
    stock = product.stock_for(size)
    if stock <= 0:
        raise CartError(f"Size {size} is sold out.")
    if qty > stock:
        raise CartError(f"Only {stock} pair{'s' if stock != 1 else ''} left in size {size}.")
    return product


def add_item(cart: Cart, product_id: int, size: int | None, qty: int = 1) -> None:
    if size is None:
        raise CartError("Please choose a size first.")
    if qty < 1:
        raise CartError("Quantity must be at least 1.")
    key = (product_id, size)
    _check(product_id, size, cart.items.get(key, 0) + qty)
    cart.items[key] = cart.items.get(key, 0) + qty


def update_qty(cart: Cart, product_id: int, size: int, qty: int) -> None:
    key = (product_id, size)
    if key not in cart.items:
        return
    if qty <= 0:
        del cart.items[key]
        return
    _check(product_id, size, qty)
    cart.items[key] = qty


def remove_item(cart: Cart, product_id: int, size: int) -> None:
    cart.items.pop((product_id, size), None)


def summarize(cart: Cart) -> CartSummary:
    lines: list[CartLine] = []
    for (pid, size), qty in cart.items.items():
        p = catalog_service.get_product(pid)
        if not p or not p.is_active:
            continue
        lines.append(CartLine(product_id=pid, size_eu=size, quantity=qty, name=p.name,
                              image_path=p.image_path, unit_price=p.price, available=p.stock_for(size)))
    subtotal = sum(l.line_total for l in lines)  # total = sum(unit_price x quantity)
    fee = config.DELIVERY_FEE if lines else 0
    return CartSummary(lines=lines, subtotal=subtotal, delivery_fee=fee, total=subtotal + fee)
