"""Checkout and order lifecycle (FR-4, FR-5, FR-6)."""
from __future__ import annotations

import re

from .. import config, db
from ..models import Order
from ..repositories import OrderRepository, ProductRepository
from .cart_service import Cart
from .errors import OrderError, StockError, ValidationError

_PHONE_RE = re.compile(r"^\+?\d[\d\s-]{8,16}$")


def _validate_shipping(shipping: dict) -> dict:
    name = (shipping.get("name") or "").strip()
    phone = (shipping.get("phone") or "").strip()
    address = (shipping.get("address") or "").strip()
    method = shipping.get("payment_method")
    if len(name) < 2 or len(name) > config.MAX_NAME_LEN:
        raise ValidationError("Please enter your full name.")
    if not _PHONE_RE.match(phone):
        raise ValidationError("Please enter a valid phone number.")
    if len(address) < 8 or len(address) > config.MAX_ADDRESS_LEN:
        raise ValidationError(f"Please enter a full delivery address (up to {config.MAX_ADDRESS_LEN} characters).")
    if method not in config.PAYMENT_METHODS:
        raise ValidationError("Please choose a payment method.")
    return {"name": name, "phone": phone, "address": address, "payment_method": method}


def checkout(buyer_id: int, cart: Cart, shipping: dict) -> Order:
    """Validate live stock + price, decrement stock atomically, create the order.

    If any line cannot be fulfilled nothing is written and a StockError lists
    every problem line so the buyer can adjust the cart (Phase 2, 2.2).
    """
    ship = _validate_shipping(shipping)
    if not cart.items:
        raise OrderError("Your cart is empty.")

    with db.get_conn() as conn:
        db.begin_write(conn)  # take the write lock: concurrent checkouts are serialised
        products = ProductRepository(conn)
        orders = OrderRepository(conn)

        issues: list[str] = []
        priced: list[tuple[int, int, int, int]] = []  # product_id, size, qty, live unit price
        for (pid, size), qty in cart.items.items():
            p = products.get(pid)
            if not p or not p.is_active:
                issues.append("A shoe in your cart is no longer available")
                continue
            have = p.stock_for(size)
            if have < qty:
                issues.append(f"{p.name} (EU {size}): only {have} left" if have else f"{p.name} (EU {size}) is sold out")
                continue
            priced.append((pid, size, qty, p.price))
        if issues:
            raise StockError(issues)

        subtotal = sum(price * qty for _, _, qty, price in priced)
        fee = config.DELIVERY_FEE
        order_id = orders.create(buyer_id, subtotal + fee, fee, ship["name"], ship["phone"],
                                 ship["address"], ship["payment_method"])
        for pid, size, qty, price in priced:
            if not products.decrement_stock(pid, size, qty):  # guarded UPDATE: never oversells
                raise StockError([f"Stock changed for a shoe in your cart (EU {size}); please review it"])
            orders.add_item(order_id, pid, size, qty, price)
        order = orders.get(order_id)
    return order


def list_for_buyer(buyer_id: int) -> list[Order]:
    with db.get_conn() as conn:
        return OrderRepository(conn).list_for_buyer(buyer_id)


def list_for_seller(seller_id: int) -> list[Order]:
    with db.get_conn() as conn:
        return OrderRepository(conn).list_for_seller(seller_id)


def next_statuses(status: str) -> list[str]:
    return config.ORDER_TRANSITIONS.get(status, [])


def update_status(seller_id: int, order_id: int, new_status: str) -> Order:
    """Forward-only transitions; cancelling a pending order returns its stock."""
    with db.get_conn() as conn:
        db.begin_write(conn)
        orders = OrderRepository(conn)
        products = ProductRepository(conn)
        order = orders.get(order_id)
        if not order or not orders.seller_owns_order(seller_id, order_id):
            raise OrderError("Order not found.")
        if new_status not in next_statuses(order.status):
            raise OrderError(f"An order that is {order.status} cannot be changed to {new_status}.")
        if new_status == "cancelled":
            for it in order.items:
                products.increment_stock(it.product_id, it.size_eu, it.quantity)
        orders.set_status(order_id, new_status)
        return orders.get(order_id)


STATUS_MESSAGES = {  # FR-6: plain-language status shown to the buyer
    "pending": "We have received your order and the seller is preparing it.",
    "shipped": "Your order is on its way to you.",
    "delivered": "Your order has been delivered. Enjoy your new shoes!",
    "cancelled": "This order was cancelled.",
}
