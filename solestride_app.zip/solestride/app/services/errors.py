"""Domain errors raised by the service layer and shown to the user by the UI."""


class ServiceError(Exception):
    """Base class. str(error) is always safe to display to the user."""


class AuthError(ServiceError):
    pass


class ValidationError(ServiceError):
    pass


class CatalogError(ServiceError):
    pass


class CartError(ServiceError):
    pass


class OrderError(ServiceError):
    pass


class StockError(OrderError):
    """Raised at checkout when one or more cart lines cannot be fulfilled."""

    def __init__(self, issues: list[str]):
        self.issues = issues
        super().__init__("Some items need your attention: " + "; ".join(issues))
