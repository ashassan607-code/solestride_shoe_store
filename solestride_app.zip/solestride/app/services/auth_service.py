"""Registration, login and password hashing (FR-1, NFR-3).

Passwords are hashed with PBKDF2-HMAC-SHA256 and a per-user random salt.
Plaintext passwords are never stored, logged, or returned.
"""
from __future__ import annotations

import hashlib
import hmac
import re
import secrets

from .. import config, db
from ..models import User
from ..repositories import LoginAttemptRepository, UserRepository
from .errors import AuthError, ValidationError

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def hash_password(password: str, iterations: int | None = None) -> str:
    iterations = iterations or config.PBKDF2_ITERATIONS
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return f"pbkdf2_sha256${iterations}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, iters, salt_hex, digest_hex = stored.split("$")
        if scheme != "pbkdf2_sha256":
            return False
        digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), int(iters))
        return hmac.compare_digest(digest.hex(), digest_hex)
    except (ValueError, TypeError):
        return False


def register(name: str, email: str, password: str, role: str = config.ROLE_BUYER,
             trusted: bool = False) -> User:
    """Create an account. `trusted=True` is for the owner-only admin CLI (manage.py)."""
    name = (name or "").strip()
    email = (email or "").strip().lower()
    if len(name) < 2 or len(name) > config.MAX_NAME_LEN:
        raise ValidationError(f"Please enter your full name (up to {config.MAX_NAME_LEN} characters).")
    if len(email) > config.MAX_EMAIL_LEN or not _EMAIL_RE.match(email):
        raise ValidationError("Please enter a valid email address.")
    if not (config.PASSWORD_MIN_LENGTH <= len(password or "") <= config.MAX_PASSWORD_LEN):
        raise ValidationError(
            f"Password must be {config.PASSWORD_MIN_LENGTH} to {config.MAX_PASSWORD_LEN} characters.")
    if role not in (config.ROLE_BUYER, config.ROLE_SELLER):
        raise ValidationError("Invalid account type.")
    if role == config.ROLE_SELLER and not (trusted or config.ALLOW_SELLER_SIGNUP):
        raise ValidationError("Seller accounts are created by the store owner.")
    with db.get_conn() as conn:
        repo = UserRepository(conn)
        if repo.get_by_email(email):
            raise ValidationError("An account with this email already exists.")
        return repo.create(name, email, hash_password(password), role)


def login(email: str, password: str) -> User:
    email = (email or "").strip().lower()
    generic = "Incorrect email or password."
    if len(email) > config.MAX_EMAIL_LEN or len(password or "") > config.MAX_PASSWORD_LEN:
        raise AuthError(generic)
    with db.get_conn() as conn:
        if LoginAttemptRepository(conn).recent_failures(email, config.LOGIN_LOCKOUT_MINUTES) >= config.LOGIN_MAX_FAILURES:
            locked = True
            found = None
        else:
            locked = False
            found = UserRepository(conn).get_by_email(email)
    if locked:  # applies to every email string, so it does not reveal which accounts exist
        raise AuthError(f"Too many failed attempts. Please wait {config.LOGIN_LOCKOUT_MINUTES} minutes and try again.")
    ok = bool(found) and verify_password(password or "", found[1])
    with db.get_conn() as conn:
        attempts = LoginAttemptRepository(conn)
        attempts.clear(email) if ok else attempts.record_failure(email)
    if not ok:
        # Same message for unknown email and wrong password: do not reveal which accounts exist.
        raise AuthError(generic)
    return found[0]
