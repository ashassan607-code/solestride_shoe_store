"""Reusable controls: header, product card, size chips, quantity stepper."""
import flet as ft

from .. import config
from . import theme as t


def header(app) -> ft.Control:
    logo = ft.Container(content=ft.Image(src="logo_full.png", height=40, fit=ft.BoxFit.CONTAIN),
                        on_click=lambda e: app.go("home"), ink=False)
    search = ft.TextField(
        value=app.filters["q"], hint_text="Search shoes...", prefix_icon=ft.Icons.SEARCH, dense=True,
        height=40, border_radius=t.RADIUS, bgcolor=t.WHITE, content_padding=ft.Padding.symmetric(horizontal=8),
        on_change=lambda e: app.on_search(e.control.value), on_submit=lambda e: app.on_search_submit(),
        expand=True,
    )
    n = len(app.cart)
    cart_btn = ft.IconButton(icon=ft.Icons.SHOPPING_CART_OUTLINED, tooltip="Cart",
                             badge=ft.Badge(label=str(n), bgcolor=t.ORANGE) if n else None,
                             on_click=lambda e: app.go("cart"))
    nav: list[ft.Control] = [cart_btn]
    if app.user:
        if app.user.is_seller:
            nav.append(ft.TextButton("Dashboard", on_click=lambda e: app.go("seller", tab="products")))
        else:
            nav.append(ft.TextButton("My Orders", on_click=lambda e: app.go("orders")))
        nav.append(ft.Text(app.user.name.split()[0], size=13, color=t.NAVY, weight=ft.FontWeight.W_600))
        nav.append(ft.TextButton("Logout", on_click=lambda e: app.logout()))
    else:
        nav.append(t.primary_button("Login / Register", lambda e: app.go("login", mode="login")))
    return ft.Container(
        content=ft.Row([logo, ft.Container(search, expand=True, width=300), ft.Row(nav, spacing=4, wrap=True)],
                       alignment=ft.MainAxisAlignment.SPACE_BETWEEN, vertical_alignment=ft.CrossAxisAlignment.CENTER,
                       wrap=True, run_spacing=6),
        bgcolor=t.HEADER_BG, padding=ft.Padding.symmetric(horizontal=16, vertical=8),
        border=ft.Border(bottom=ft.BorderSide(1, t.BORDER)),
    )


def stock_label(product, size=None):
    """Return (text, color) describing availability."""
    if size is not None:
        have = product.stock_for(size)
        if have <= 0:
            return "Sold out in this size", t.RED
        if have <= config.LOW_STOCK_THRESHOLD:
            return f"Only {have} pair{'s' if have != 1 else ''} left", t.ORANGE
        return f"In stock ({have} pairs available)", t.GREEN
    total = product.total_stock
    if total <= 0:
        return "Sold out", t.RED
    return f"{total} pairs in stock", t.GREEN


def product_card(app, p) -> ft.Control:
    text, color = stock_label(p)
    return ft.Container(
        width=230, padding=10, bgcolor="#FAFAFA", border=ft.Border.all(1, t.BORDER), border_radius=t.RADIUS,
        on_click=lambda e, pid=p.id: app.go("detail", product_id=pid, size=None, qty=1),
        content=ft.Column([
            ft.Image(src=p.image_path, height=140, width=210, fit=ft.BoxFit.COVER, border_radius=t.RADIUS),
            ft.Text(p.name, size=14, weight=ft.FontWeight.W_600, color=t.TEXT),
            t.muted(p.category),
            ft.Row([ft.Text(t.money(p.price), size=15, weight=ft.FontWeight.BOLD, color=t.NAVY),
                    ft.Text(text, size=11, color=color)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ft.Container(content=t.accent_button("Choose size", lambda e, pid=p.id: app.go(
                "detail", product_id=pid, size=None, qty=1)), alignment=ft.Alignment.CENTER_RIGHT),
        ], spacing=5),
    )


def size_chips(product, selected, on_pick) -> ft.Control:
    chips = []
    for size in config.SIZES:
        have = product.stock_for(size)
        active = selected == size
        sold_out = have <= 0
        chips.append(ft.Container(
            content=ft.Text(str(size), size=13, color=t.WHITE if active else (t.MUTED if sold_out else t.TEXT),
                            weight=ft.FontWeight.W_600),
            width=46, height=38, alignment=ft.Alignment.CENTER, border_radius=t.RADIUS,
            bgcolor=t.NAVY if active else (t.PANEL if sold_out else t.WHITE),
            border=ft.Border.all(1, t.NAVY if active else t.BORDER),
            opacity=0.55 if sold_out else 1.0, tooltip="Sold out" if sold_out else f"EU {size}",
            on_click=None if sold_out else (lambda e, s=size: on_pick(s)),
        ))
    return ft.Row(chips, wrap=True, spacing=8, run_spacing=8)


def stepper(value, on_change) -> ft.Control:
    return ft.Row([
        ft.IconButton(ft.Icons.REMOVE, icon_size=18, on_click=lambda e: on_change(value - 1)),
        ft.Text(str(value), size=15, weight=ft.FontWeight.W_600, width=26, text_align=ft.TextAlign.CENTER),
        ft.IconButton(ft.Icons.ADD, icon_size=18, on_click=lambda e: on_change(value + 1)),
    ], spacing=0, tight=True)


def empty_state(icon, message, button_text=None, on_click=None) -> ft.Control:
    items: list[ft.Control] = [ft.Icon(icon, size=48, color=t.MUTED), ft.Text(message, size=16, color=t.MUTED)]
    if button_text:
        items.append(t.accent_button(button_text, on_click))
    return ft.Container(content=ft.Column(items, horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=14),
                        padding=40, alignment=ft.Alignment.CENTER)
