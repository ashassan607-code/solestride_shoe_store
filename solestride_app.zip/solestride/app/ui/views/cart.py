"""Cart: line items with size + quantity control, order summary (Fig 3)."""
import flet as ft

from ...services import cart_service
from ...services.errors import ServiceError
from .. import components as c
from .. import theme as t


def build(app) -> ft.Control:
    summary = cart_service.summarize(app.cart)
    if not summary.lines:
        return c.empty_state(ft.Icons.SHOPPING_CART_OUTLINED, "Your cart is empty.", "Browse shoes",
                             lambda e: app.go("home"))

    def change(line, n):
        try:
            cart_service.update_qty(app.cart, line.product_id, line.size_eu, n)
        except ServiceError as ex:
            app.toast(str(ex), error=True)
            return
        app.render()

    def remove(line):
        cart_service.remove_item(app.cart, line.product_id, line.size_eu)
        app.render()

    rows = []
    for line in summary.lines:
        rows.append(t.card(ft.Row([
            ft.Image(src=line.image_path, width=72, height=56, fit=ft.BoxFit.COVER, border_radius=t.RADIUS),
            ft.Column([
                ft.Text(line.name, size=14, weight=ft.FontWeight.W_600),
                t.muted(f"EU {line.size_eu}  |  {t.money(line.unit_price)} each"),
                c.stepper(line.quantity, lambda n, l=line: change(l, n)),
            ], spacing=2, expand=True),
            ft.Column([
                ft.Text(t.money(line.line_total), size=14, weight=ft.FontWeight.BOLD, color=t.NAVY),
                ft.TextButton("Remove", style=ft.ButtonStyle(color=t.RED), on_click=lambda e, l=line: remove(l)),
            ], horizontal_alignment=ft.CrossAxisAlignment.END, spacing=0),
        ], vertical_alignment=ft.CrossAxisAlignment.CENTER), bgcolor="#FAFAFA"))

    def kv(label, value, bold=False):
        return ft.Row([ft.Text(label, size=13, color=t.MUTED if not bold else t.TEXT,
                               weight=ft.FontWeight.BOLD if bold else None),
                       ft.Text(value, size=14 if bold else 13, weight=ft.FontWeight.BOLD if bold else None)],
                      alignment=ft.MainAxisAlignment.SPACE_BETWEEN)

    panel = t.card(ft.Column([
        ft.Text("Order Summary", size=16, weight=ft.FontWeight.BOLD),
        kv(f"Subtotal ({summary.item_count} pair{'s' if summary.item_count != 1 else ''})", t.money(summary.subtotal)),
        kv("Delivery", t.money(summary.delivery_fee)),
        ft.Divider(height=8),
        kv("Total", t.money(summary.total), bold=True),
        t.primary_button("Checkout", lambda e: app.go("checkout"), icon=ft.Icons.LOCK_OUTLINE),
        ft.TextButton("Continue shopping", on_click=lambda e: app.go("home")),
    ], spacing=10))

    return ft.Column([
        t.title("Your Cart"),
        ft.ResponsiveRow([
            ft.Column(rows, spacing=10, col={"xs": 12, "md": 8}),
            ft.Container(panel, col={"xs": 12, "md": 4}),
        ], spacing=20, run_spacing=16),
    ], spacing=14)
