"""Shoe detail: image, price, size selector, quantity, add to cart (Fig 2)."""
import flet as ft

from ...services import cart_service, catalog_service
from ...services.errors import ServiceError
from .. import components as c
from .. import theme as t


def build(app) -> ft.Control:
    product = catalog_service.get_product(app.params.get("product_id", 0))
    if not product or not product.is_active:
        return c.empty_state(ft.Icons.ERROR_OUTLINE, "This shoe is no longer available.", "Back to shoes",
                             lambda e: app.go("home"))
    size = app.params.get("size")
    qty = app.params.get("qty", 1)

    def pick_size(s):
        app.go("detail", product_id=product.id, size=s, qty=1)

    def set_qty(n):
        n = max(1, n)
        if size is not None and n > product.stock_for(size):
            app.toast(f"Only {product.stock_for(size)} pairs left in size {size}.", error=True)
            return
        app.go("detail", product_id=product.id, size=size, qty=n)

    def add(e):
        try:
            cart_service.add_item(app.cart, product.id, size, qty)
        except ServiceError as ex:
            app.toast(str(ex), error=True)
            return
        app.toast(f"Added {qty} x {product.name} (EU {size}) to your cart.")
        app.go("detail", product_id=product.id, size=size, qty=1)

    if size is None:
        stock_text, stock_color = "Select a size to see availability", t.MUTED
    else:
        stock_text, stock_color = c.stock_label(product, size)

    info = ft.Column([
        ft.Text(product.name, size=26, weight=ft.FontWeight.BOLD, color=t.NAVY),
        t.muted(product.category, 13),
        ft.Text(t.money(product.price), size=22, weight=ft.FontWeight.BOLD, color=t.NAVY),
        ft.Text(stock_text, size=13, color=stock_color),
        ft.Text("Select size (EU)", size=13, color=t.MUTED),
        c.size_chips(product, size, pick_size),
        ft.Text("Description", size=13, color=t.MUTED),
        t.card(ft.Text(product.description or "No description provided.", size=13, color=t.TEXT), bgcolor="#FAFAFA"),
        ft.Text("Quantity", size=13, color=t.MUTED),
        c.stepper(qty, set_qty),
        t.accent_button("Add to Cart", add, icon=ft.Icons.ADD_SHOPPING_CART, disabled=size is None),
        ft.TextButton("View cart", icon=ft.Icons.SHOPPING_CART_OUTLINED, on_click=lambda e: app.go("cart")),
    ], spacing=10)

    return ft.Column([
        ft.TextButton("Back to shoes", icon=ft.Icons.ARROW_BACK, on_click=lambda e: app.go("home")),
        ft.ResponsiveRow([
            ft.Container(ft.Image(src=product.image_path, fit=ft.BoxFit.COVER, border_radius=t.RADIUS,
                                  aspect_ratio=4 / 3), col={"xs": 12, "md": 6}),
            ft.Container(info, col={"xs": 12, "md": 6}, padding=ft.Padding.only(left=8)),
        ], spacing=20, run_spacing=16),
    ], spacing=10)
