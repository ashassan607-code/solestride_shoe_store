"""Seller dashboard: sidebar nav, shoe table, orders, stock levels (Fig 5; FR-1, FR-5, FR-7)."""
import flet as ft

from ... import config
from ...services import catalog_service, order_service
from ...services.errors import ServiceError
from .. import theme as t


def _available_images() -> list[str]:
    folder = config.ASSETS_DIR / "shoes"
    return sorted(f"shoes/{p.name}" for p in folder.glob("*.png")) if folder.exists() else []


def build(app) -> ft.Control:
    if not app.user or not app.user.is_seller:
        return app.redirect("login", mode="login", next="seller")
    tab = app.params.get("tab", "products")

    def nav_item(label, key, icon):
        active = tab == key
        return ft.Container(
            content=ft.Row([ft.Icon(icon, color=t.WHITE, size=18), ft.Text(label, color=t.WHITE, size=14,
                                                                           weight=ft.FontWeight.W_600 if active else None)], spacing=10),
            padding=ft.Padding.symmetric(horizontal=14, vertical=11),
            bgcolor="#2C4160" if active else None, border=ft.Border(left=ft.BorderSide(4, t.ORANGE if active else t.NAVY)),
            on_click=lambda e, k=key: app.go("seller", tab=k))

    sidebar = ft.Container(
        content=ft.Column([nav_item("Products", "products", ft.Icons.INVENTORY_2_OUTLINED),
                           nav_item("Orders", "orders", ft.Icons.RECEIPT_LONG_OUTLINED),
                           nav_item("Stock", "stock", ft.Icons.WAREHOUSE_OUTLINED),
                           ft.Container(content=ft.TextButton("View store", icon=ft.Icons.STOREFRONT,
                                                              style=ft.ButtonStyle(color="#C8D0DC"),
                                                              on_click=lambda e: app.go("home")),
                                        padding=ft.Padding.only(top=12))], spacing=0),
        bgcolor=t.NAVY, border_radius=t.RADIUS, padding=ft.Padding.symmetric(vertical=10))

    body = {"products": products_tab, "orders": orders_tab, "stock": stock_tab}.get(tab, products_tab)(app)
    return ft.Column([
        t.title("Seller Dashboard"),
        ft.ResponsiveRow([ft.Container(sidebar, col={"xs": 12, "md": 3, "lg": 2}),
                          ft.Container(body, col={"xs": 12, "md": 9, "lg": 10})], spacing=16, run_spacing=12),
    ], spacing=12)


# ---------------------------------------------------------------- products
def products_tab(app) -> ft.Control:
    products = catalog_service.list_products(seller_id=app.user.id)

    def stock_cell(p):
        low = any(q <= config.LOW_STOCK_THRESHOLD for q in p.sizes.values())
        text = f"{p.total_stock} pairs" + ("  (low sizes)" if low else "")
        return ft.Text(text, size=12, color=t.RED if low else t.TEXT)

    rows = [ft.DataRow(cells=[
        ft.DataCell(ft.Row([ft.Image(src=p.image_path, width=40, height=30, fit=ft.BoxFit.COVER, border_radius=3),
                            ft.Text(p.name, size=13)], spacing=8)),
        ft.DataCell(ft.Text(p.category, size=12)),
        ft.DataCell(ft.Text(t.money(p.price), size=12)),
        ft.DataCell(stock_cell(p)),
        ft.DataCell(ft.Row([ft.TextButton("Edit", on_click=lambda e, p=p: open_editor(app, p)),
                            ft.TextButton("Delete", style=ft.ButtonStyle(color=t.RED),
                                          on_click=lambda e, p=p: confirm_delete(app, p))], spacing=0)),
    ]) for p in products]

    table = ft.DataTable(
        columns=[ft.DataColumn(ft.Text(h, size=12, weight=ft.FontWeight.BOLD)) for h in
                 ["Shoe", "Category", "Price", "Stock", "Actions"]],
        rows=rows, heading_row_color="#E8ECF2", column_spacing=24, data_row_min_height=44, data_row_max_height=48)
    return ft.Column([
        ft.Row([ft.Text("Products", size=18, weight=ft.FontWeight.BOLD),
                t.accent_button("+ Add Product", lambda e: open_editor(app, None))],
               alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
        ft.Row([table], scroll=ft.ScrollMode.AUTO) if products else
        t.muted("No listings yet. Add your first shoe.", 13),
    ], spacing=10)


def open_editor(app, product) -> None:
    editing = product is not None
    name = ft.TextField(label="Shoe name", value=product.name if editing else "")
    desc = ft.TextField(label="Description", value=product.description if editing else "", multiline=True, min_lines=2, max_lines=4)
    price = ft.TextField(label=f"Price ({config.CURRENCY})", value=str(product.price) if editing else "",
                         keyboard_type=ft.KeyboardType.NUMBER)
    cat = ft.Dropdown(label="Category", value=product.category if editing else None,
                      options=[ft.DropdownOption(key=c, text=c) for c in config.CATEGORIES])
    imgs = _available_images()
    image = ft.Dropdown(label="Image", value=(product.image_path if editing else (imgs[0] if imgs else None)),
                        options=[ft.DropdownOption(key=i, text=i.split("/")[-1].replace(".png", "").replace("_", " ").title()) for i in imgs])
    size_fields = {s: ft.TextField(label=f"EU {s}", width=78, dense=True, keyboard_type=ft.KeyboardType.NUMBER,
                                   value=str(product.stock_for(s) if editing else 0)) for s in config.SIZES}
    error = ft.Text("", color=t.RED, size=12, visible=False)

    def save(e):
        data = {"name": name.value, "description": desc.value, "price": price.value, "category": cat.value,
                "image_path": image.value, "sizes": {s: f.value for s, f in size_fields.items()}}
        try:
            catalog_service.upsert_product(app.user.id, data, product.id if editing else None)
        except ServiceError as ex:
            error.value, error.visible = str(ex), True
            app.page.update()
            return
        app.page.pop_dialog()
        app.toast("Listing saved.")
        app.render()

    app.page.show_dialog(ft.AlertDialog(
        modal=True, title=ft.Text("Edit shoe" if editing else "Add a shoe"),
        content=ft.Container(width=440, content=ft.Column([
            name, desc, price, cat, image, ft.Text("Stock per size (pairs)", size=13, color=t.MUTED),
            ft.Row(list(size_fields.values()), wrap=True, spacing=8, run_spacing=8), error,
        ], tight=True, spacing=10, scroll=ft.ScrollMode.AUTO)),
        actions=[ft.TextButton("Cancel", on_click=lambda e: app.page.pop_dialog()), t.accent_button("Save", save)],
    ))


def confirm_delete(app, product) -> None:
    def do_delete(e):
        try:
            catalog_service.delete_product(app.user.id, product.id)
        except ServiceError as ex:
            app.toast(str(ex), error=True)
        app.page.pop_dialog()
        app.toast(f"{product.name} removed from the store.")
        app.render()

    app.page.show_dialog(ft.AlertDialog(
        modal=True, title=ft.Text("Delete listing?"),
        content=ft.Text(f"{product.name} will no longer appear in the store. Past orders are kept."),
        actions=[ft.TextButton("Cancel", on_click=lambda e: app.page.pop_dialog()),
                 t.danger_button("Delete", do_delete)],
    ))


# ------------------------------------------------------------------ orders
def orders_tab(app) -> ft.Control:
    orders = order_service.list_for_seller(app.user.id)
    if not orders:
        return ft.Column([ft.Text("Orders", size=18, weight=ft.FontWeight.BOLD), t.muted("No orders yet.", 13)])

    def move(order, status):
        try:
            order_service.update_status(app.user.id, order.id, status)
        except ServiceError as ex:
            app.toast(str(ex), error=True)
            return
        app.toast(f"{order.reference} marked as {status}.")
        app.render()

    cards = []
    for o in orders:
        actions = []
        for nxt in order_service.next_statuses(o.status):
            if nxt == "cancelled":
                actions.append(t.danger_button("Cancel order", lambda e, o=o: move(o, "cancelled")))
            else:
                actions.append(t.primary_button(f"Mark as {nxt}", lambda e, o=o, n=nxt: move(o, n)))
        cards.append(t.card(ft.Column([
            ft.Row([ft.Text(o.reference, size=15, weight=ft.FontWeight.BOLD, color=t.NAVY), t.status_badge(o.status)],
                   alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            t.muted(f"{o.buyer_name}  |  {o.phone}  |  {config.PAYMENT_METHODS.get(o.payment_method, o.payment_method)}  |  {o.created_at}"),
            t.muted(f"Deliver to: {o.address}"),
            *[ft.Text(f"{i.quantity} x {i.name} (EU {i.size_eu})", size=13) for i in o.items],
            ft.Row([ft.Text(f"Total {t.money(o.total)}", size=13, weight=ft.FontWeight.BOLD),
                    ft.Row(actions, wrap=True, spacing=8)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN, wrap=True),
        ], spacing=6), bgcolor="#FAFAFA"))
    return ft.Column([ft.Text("Orders", size=18, weight=ft.FontWeight.BOLD), *cards], spacing=10)


# ------------------------------------------------------------------- stock
def stock_tab(app) -> ft.Control:
    products = catalog_service.list_products(seller_id=app.user.id)
    low = catalog_service.low_stock(app.user.id)
    if low:
        alert = t.card(ft.Column([
            ft.Row([ft.Icon(ft.Icons.WARNING_AMBER_ROUNDED, color=t.ORANGE), ft.Text(f"{len(low)} size(s) running low", weight=ft.FontWeight.BOLD)]),
            ft.Text(", ".join(f"{p.name} EU {s} ({q} left)" if q else f"{p.name} EU {s} (sold out)" for p, s, q in low), size=12),
        ], spacing=4), bgcolor="#FFF6EE")
    else:
        alert = t.card(ft.Row([ft.Icon(ft.Icons.CHECK_CIRCLE_OUTLINE, color=t.GREEN), ft.Text("All sizes are well stocked.")]))

    def cell(q):
        low_q = q <= config.LOW_STOCK_THRESHOLD
        return ft.DataCell(ft.Text(str(q), size=12, color=t.RED if low_q else t.TEXT,
                                   weight=ft.FontWeight.BOLD if low_q else None))

    table = ft.DataTable(
        columns=[ft.DataColumn(ft.Text("Shoe", size=12, weight=ft.FontWeight.BOLD))] +
                [ft.DataColumn(ft.Text(str(s), size=12, weight=ft.FontWeight.BOLD), numeric=True) for s in config.SIZES],
        rows=[ft.DataRow(cells=[ft.DataCell(ft.Text(p.name, size=12))] + [cell(p.stock_for(s)) for s in config.SIZES]) for p in products],
        heading_row_color="#E8ECF2", column_spacing=18, data_row_min_height=38, data_row_max_height=42)
    return ft.Column([
        ft.Text("Stock by size (EU)", size=18, weight=ft.FontWeight.BOLD), alert,
        t.muted(f"Red = {config.LOW_STOCK_THRESHOLD} pairs or fewer. Edit a listing to restock.", 12),
        ft.Row([table], scroll=ft.ScrollMode.AUTO),
    ], spacing=10)
