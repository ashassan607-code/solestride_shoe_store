"""Buyer order history with plain-language status notifications (FR-6)."""
import flet as ft

from ...services import order_service
from .. import components as c
from .. import theme as t


def build(app) -> ft.Control:
    if not app.user:
        return app.redirect("login", mode="login", next="orders")
    orders = order_service.list_for_buyer(app.user.id)
    if not orders:
        return c.empty_state(ft.Icons.RECEIPT_LONG_OUTLINED, "You have not placed any orders yet.",
                             "Browse shoes", lambda e: app.go("home"))
    cards = []
    for o in orders:
        items = [ft.Text(f"{i.quantity} x {i.name} (EU {i.size_eu})  -  {t.money(i.unit_price * i.quantity)}", size=13)
                 for i in o.items]
        cards.append(t.card(ft.Column([
            ft.Row([ft.Text(o.reference, size=16, weight=ft.FontWeight.BOLD, color=t.NAVY), t.status_badge(o.status)],
                   alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ft.Text(order_service.STATUS_MESSAGES[o.status], size=13, color=t.TEXT),
            t.muted(f"Placed {o.created_at}  |  last update {o.status_updated_at}"),
            *items,
            ft.Divider(height=6),
            ft.Row([t.muted(f"Delivery to: {o.address}"),
                    ft.Text(t.money(o.total), size=14, weight=ft.FontWeight.BOLD)],
                   alignment=ft.MainAxisAlignment.SPACE_BETWEEN, wrap=True),
        ], spacing=6), bgcolor="#FAFAFA"))
    return ft.Column([t.title("My Orders"), *cards], spacing=12)
