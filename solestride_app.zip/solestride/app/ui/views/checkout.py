"""Checkout: delivery form, payment method, order summary (Fig 4) and confirmation."""
import asyncio

import flet as ft

from ... import config
from ...services import cart_service, order_service
from ...services.errors import ServiceError, StockError
from .. import components as c
from .. import theme as t


def build(app) -> ft.Control:
    if not app.user:
        app.toast("Please log in to place your order.")
        return app.redirect("login", mode="login", next="checkout")
    summary = cart_service.summarize(app.cart)
    if not summary.lines:
        return c.empty_state(ft.Icons.SHOPPING_CART_OUTLINED, "Your cart is empty.", "Browse shoes",
                             lambda e: app.go("home"))

    name = ft.TextField(label="Full name", value=app.user.name)
    phone = ft.TextField(label="Phone number", keyboard_type=ft.KeyboardType.PHONE, hint_text="08031234567")
    address = ft.TextField(label="Delivery address", multiline=True, min_lines=3, max_lines=4)
    pay = ft.RadioGroup(value="pay_on_delivery", content=ft.Column([
        ft.Radio(value=k, label=v) for k, v in config.PAYMENT_METHODS.items()]))
    error = ft.Text("", color=t.RED, size=13, visible=False)
    review_btn = ft.TextButton("Review my cart", visible=False, on_click=lambda e: app.go("cart"))
    place = t.primary_button("Place Order", None, icon=ft.Icons.CHECK)

    async def do_place(e):
        error.visible = review_btn.visible = False
        place.disabled = True
        app.page.update()
        shipping = {"name": name.value, "phone": phone.value, "address": address.value, "payment_method": pay.value}
        try:
            order = await asyncio.to_thread(order_service.checkout, app.user.id, app.cart, shipping)
        except StockError as ex:
            error.value, error.visible, review_btn.visible = str(ex), True, True
            place.disabled = False
            app.page.update()
            return
        except ServiceError as ex:
            error.value, error.visible = str(ex), True
            place.disabled = False
            app.page.update()
            return
        except Exception:
            error.value, error.visible = "We could not place your order. Please try again.", True
            place.disabled = False
            app.page.update()
            return
        app.cart.clear()
        app.go("order_done", order_id=order.id, reference=order.reference, total=order.total)

    place.on_click = do_place

    lines = [ft.Row([ft.Text(f"{l.quantity} x {l.name} (EU {l.size_eu})", size=12, expand=True),
                     ft.Text(t.money(l.line_total), size=12)]) for l in summary.lines]
    panel = t.card(ft.Column([
        ft.Text("Order Summary", size=16, weight=ft.FontWeight.BOLD), *lines, ft.Divider(height=8),
        ft.Row([ft.Text("Delivery", size=12, color=t.MUTED), ft.Text(t.money(summary.delivery_fee), size=12)],
               alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
        ft.Row([ft.Text("Total", size=14, weight=ft.FontWeight.BOLD),
                ft.Text(t.money(summary.total), size=14, weight=ft.FontWeight.BOLD)],
               alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
    ], spacing=8))

    form = ft.Column([
        name, phone, address, ft.Text("Payment method", size=13, color=t.MUTED), pay,
        t.muted("MVP note: no real payment is processed. Gateway integration is planned for the production phase.", 11),
        error, review_btn, place,
    ], spacing=12)
    return ft.Column([t.title("Checkout"), ft.ResponsiveRow([
        ft.Container(form, col={"xs": 12, "md": 7}), ft.Container(panel, col={"xs": 12, "md": 5})],
        spacing=20, run_spacing=16)], spacing=14)


def build_done(app) -> ft.Control:
    ref = app.params.get("reference", "")
    return ft.Container(alignment=ft.Alignment.TOP_CENTER, padding=30, content=t.card(ft.Column([
        ft.Icon(ft.Icons.CHECK_CIRCLE, size=56, color=t.GREEN),
        ft.Text("Order placed!", size=24, weight=ft.FontWeight.BOLD, color=t.NAVY),
        ft.Text(f"Your order ID is {ref}", size=16, weight=ft.FontWeight.W_600),
        ft.Text(f"Total: {t.money(app.params.get('total', 0))}", size=14),
        t.muted("The seller has been notified. You can follow its status under My Orders.", 13),
        ft.Row([t.primary_button("Track my orders", lambda e: app.go("orders")),
                ft.TextButton("Continue shopping", on_click=lambda e: app.go("home"))],
               alignment=ft.MainAxisAlignment.CENTER, wrap=True),
    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10), padding=30, width=460, bgcolor=t.WHITE))
