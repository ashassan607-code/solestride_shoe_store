"""Home / shoe list: grid of cards, search, category + size filters (Fig 1)."""
import flet as ft

from ... import config
from ...services import catalog_service
from .. import components as c
from .. import theme as t


def build(app) -> ft.Control:
    grid = ft.Row(wrap=True, spacing=16, run_spacing=16)
    count = t.muted("")
    chips_row = ft.Row(wrap=True, spacing=8, run_spacing=8)

    def make_chip(label, value):
        active = (app.filters["category"] or "") == value
        return ft.Container(
            content=ft.Text(label, size=13, color=t.WHITE if active else t.TEXT),
            padding=ft.Padding.symmetric(horizontal=14, vertical=6), border_radius=18,
            bgcolor=t.NAVY if active else t.WHITE, border=ft.Border.all(1, t.NAVY if active else t.BORDER),
            on_click=lambda e, v=value: pick_category(v),
        )

    def pick_category(value):
        app.filters["category"] = value
        refresh()

    def pick_size(e):
        v = e.control.value
        app.filters["size"] = int(v) if v and v != "any" else None
        refresh()

    def refresh(update=True):
        products = catalog_service.list_products(app.filters["q"], app.filters["category"], app.filters["size"])
        grid.controls = ([c.product_card(app, p) for p in products] if products else
                         [c.empty_state(ft.Icons.SEARCH_OFF, "No shoes match your search.")])
        chips_row.controls = [make_chip("All", "")] + [make_chip(cat, cat) for cat in config.CATEGORIES]
        count.value = f"{len(products)} shoe{'s' if len(products) != 1 else ''}"
        if update:  # skipped on first build: controls are not on the page yet
            grid.update(); chips_row.update(); count.update()

    size_dd = ft.Dropdown(
        label="Size (EU)", width=150, dense=True, on_select=pick_size,
        value=str(app.filters["size"]) if app.filters["size"] else "any",
        options=[ft.DropdownOption(key="any", text="Any size")] + [ft.DropdownOption(key=str(s), text=f"EU {s}") for s in config.SIZES],
    )
    app.refresh_catalog = refresh
    refresh(update=False)
    return ft.Column([
        ft.Row([chips_row, size_dd], alignment=ft.MainAxisAlignment.SPACE_BETWEEN, wrap=True,
               vertical_alignment=ft.CrossAxisAlignment.CENTER),
        count, grid,
    ], spacing=14)
