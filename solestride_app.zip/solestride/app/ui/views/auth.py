"""Login / register (FR-1). Handlers run the blocking service call off the UI thread."""
import asyncio

import flet as ft

from ... import config
from ...services import auth_service
from ...services.errors import ServiceError
from .. import theme as t


def build(app) -> ft.Control:
    mode = app.params.get("mode", "login")
    nxt = app.params.get("next")

    name = ft.TextField(label="Full name", visible=mode == "register", autofocus=mode == "register")
    email = ft.TextField(label="Email", keyboard_type=ft.KeyboardType.EMAIL, autofocus=mode == "login")
    password = ft.TextField(label="Password", password=True, can_reveal_password=True)
    role = ft.Dropdown(label="I want to", visible=mode == "register" and config.ALLOW_SELLER_SIGNUP, value=config.ROLE_BUYER,
                       options=[ft.DropdownOption(key=config.ROLE_BUYER, text="Buy shoes"),
                                ft.DropdownOption(key=config.ROLE_SELLER, text="Sell shoes")])
    error = ft.Text("", color=t.RED, size=13, visible=False)
    submit = t.primary_button("Create account" if mode == "register" else "Log in", None)

    async def do_submit(e):
        error.visible = False
        submit.disabled = True
        app.page.update()
        try:
            if mode == "register":
                user = await asyncio.to_thread(auth_service.register, name.value, email.value,
                                               password.value, role.value or config.ROLE_BUYER)
            else:
                user = await asyncio.to_thread(auth_service.login, email.value, password.value)
        except ServiceError as ex:
            error.value, error.visible, submit.disabled = str(ex), True, False
            app.page.update()
            return
        except Exception:  # never crash the UI on an unexpected failure (NFR-5)
            error.value, error.visible, submit.disabled = "Something went wrong. Please try again.", True, False
            app.page.update()
            return
        app.user = user
        app.toast(f"Welcome, {user.name.split()[0]}!")
        if nxt:
            app.go(nxt)
        elif user.is_seller:
            app.go("seller", tab="products")
        else:
            app.go("home")

    submit.on_click = do_submit
    password.on_submit = do_submit

    switch = (ft.TextButton("New here? Create an account", on_click=lambda e: app.go("login", mode="register", next=nxt))
              if mode == "login" else
              ft.TextButton("Already have an account? Log in", on_click=lambda e: app.go("login", mode="login", next=nxt)))

    hint = (t.muted("Demo accounts - buyer: buyer@solestride.com / Buyer@123   seller: seller@solestride.com / Seller@123", 11)
            if config.SEED_DEMO else ft.Container())
    form = ft.Column([
        t.title("Create your account" if mode == "register" else "Welcome back"),
        name, email, password, role, error, submit, switch, hint,
    ], spacing=12, width=400)
    return ft.Container(content=t.card(form, padding=24, bgcolor=t.WHITE), alignment=ft.Alignment.TOP_CENTER, padding=ft.Padding.only(top=20))
