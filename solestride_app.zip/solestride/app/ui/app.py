"""Application shell: session state, navigation and error handling."""
from __future__ import annotations

import logging

import flet as ft

from .. import config
from ..services.cart_service import Cart
from . import components, theme as t
from .views import auth, cart, checkout, detail, home, orders, seller

log = logging.getLogger("solestride")

ROUTES = {
    "home": home.build, "detail": detail.build, "cart": cart.build, "checkout": checkout.build,
    "order_done": checkout.build_done, "login": auth.build, "orders": orders.build, "seller": seller.build,
}


class SoleStrideApp:
    def __init__(self, page: ft.Page):
        self.page = page
        self.user = None
        self.cart = Cart()
        self.route = "home"
        self.params: dict = {}
        self.filters = {"q": "", "category": "", "size": None}
        self.refresh_catalog = None   # set by the home view for in-place filtering
        self._redirect = None

    # ----------------------------------------------------------- lifecycle
    def start(self) -> None:
        p = self.page
        p.title = f"{config.APP_NAME} - {config.TAGLINE}"
        p.bgcolor = t.WHITE
        p.padding = 0
        p.scroll = ft.ScrollMode.AUTO
        p.theme = ft.Theme(color_scheme_seed=t.NAVY)
        try:
            p.window.width, p.window.height = 1100, 800
        except Exception:  # window settings only exist on desktop builds
            pass
        self.render()

    # ---------------------------------------------------------- navigation
    def go(self, route: str, **params) -> None:
        self.route, self.params = route, params
        self.render()

    def redirect(self, route: str, **params):
        """Used inside a view builder to send the user elsewhere (e.g. to log in)."""
        self._redirect = (route, params)
        return ft.Container()

    def render(self) -> None:
        self.refresh_catalog = None
        try:
            body = self._build_body()
            while self._redirect:                      # a view asked to redirect
                route, params = self._redirect
                self._redirect = None
                self.route, self.params = route, params
                body = self._build_body()
        except Exception:
            log.exception("Failed to render route %s", self.route)
            body = self._error_view()
        self.page.clean()
        self.page.add(components.header(self),
                      ft.Container(content=body, padding=ft.Padding.all(20)))
        self.page.update()

    def _build_body(self) -> ft.Control:
        return ROUTES.get(self.route, home.build)(self)

    def _error_view(self) -> ft.Control:
        return components.empty_state(ft.Icons.ERROR_OUTLINE, "Something went wrong. Please try again.",
                                      "Back to shoes", lambda e: self.go("home"))

    # ------------------------------------------------------------- helpers
    def toast(self, message: str, error: bool = False) -> None:
        self.page.show_dialog(ft.SnackBar(content=ft.Text(message, color=t.WHITE),
                                          bgcolor=t.RED if error else t.NAVY))

    def logout(self) -> None:
        self.user = None
        self.cart.clear()
        self.toast("You have been logged out.")
        self.go("home")

    def on_search(self, value: str) -> None:
        self.filters["q"] = value or ""
        if self.route == "home" and self.refresh_catalog:
            self.refresh_catalog()

    def on_search_submit(self) -> None:
        if self.route != "home":
            self.go("home")
