"""Palette and small UI helpers (Phase 2, section 1.3). Colors come from the SoleStride logo."""
import flet as ft

from .. import config

NAVY = "#1B2A41"       # primary: headers, sidebar, selected states
ORANGE = "#F26B1D"     # accent: Add to Cart / Add Product
TEXT = "#333333"
PANEL = "#F5F7FA"
GREEN = "#2A7A2A"
RED = "#C0392B"
WHITE = "#FFFFFF"
MUTED = "#6B7280"
BORDER = "#D9DEE5"
HEADER_BG = "#F0F0F0"
RADIUS = 4             # consistent 4px corner radius, flat design

STATUS_COLORS = {"pending": "#B7791F", "shipped": "#2B6CB0", "delivered": GREEN, "cancelled": RED}


def money(amount: int) -> str:
    return f"{config.CURRENCY}{amount:,}"


def _shape():
    return ft.RoundedRectangleBorder(radius=RADIUS)


def accent_button(text, on_click, icon=None, disabled=False):
    return ft.Button(content=text, icon=icon, on_click=on_click, bgcolor=ORANGE, color=WHITE,
                     disabled=disabled, style=ft.ButtonStyle(shape=_shape()))


def primary_button(text, on_click, icon=None, disabled=False):
    return ft.Button(content=text, icon=icon, on_click=on_click, bgcolor=NAVY, color=WHITE,
                     disabled=disabled, style=ft.ButtonStyle(shape=_shape()))


def danger_button(text, on_click, icon=None):
    return ft.OutlinedButton(content=text, icon=icon, on_click=on_click, style=ft.ButtonStyle(
        color=RED, side=ft.BorderSide(1, RED), shape=_shape()))


def card(content, padding=14, width=None, bgcolor=PANEL):
    return ft.Container(content=content, padding=padding, width=width, bgcolor=bgcolor,
                        border=ft.Border.all(1, BORDER), border_radius=RADIUS)


def title(text, size=22):
    return ft.Text(text, size=size, weight=ft.FontWeight.BOLD, color=NAVY)


def muted(text, size=12):
    return ft.Text(text, size=size, color=MUTED)


def status_badge(status: str):
    color = STATUS_COLORS.get(status, MUTED)
    return ft.Container(content=ft.Text(status.upper(), size=11, weight=ft.FontWeight.BOLD, color=WHITE),
                        bgcolor=color, padding=ft.Padding.symmetric(horizontal=8, vertical=3),
                        border_radius=RADIUS)
