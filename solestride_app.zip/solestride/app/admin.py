"""Owner/operator tasks used by manage.py: create a seller, back up the database."""
from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path

from . import config, db
from .models import User
from .services import auth_service


def create_seller(name: str, email: str, password: str) -> User:
    """Create a seller account. Sellers cannot self-register in production."""
    db.init_db(seed=False)
    return auth_service.register(name, email, password, role=config.ROLE_SELLER, trusted=True)


def backup(dest_dir: str | Path) -> Path:
    """Write a consistent copy of the database (safe while the app is running)."""
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    target = dest_dir / f"solestride-{datetime.now():%Y%m%d-%H%M%S}.db"
    src = sqlite3.connect(config.DB_PATH)
    dst = sqlite3.connect(target)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    return target
