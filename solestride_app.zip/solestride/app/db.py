"""SQLite connection helper, schema and demo seed data."""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    email         TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL CHECK (role IN ('buyer','seller'))
);
CREATE TABLE IF NOT EXISTS products (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    seller_id   INTEGER NOT NULL REFERENCES users(id),
    name        TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    price       INTEGER NOT NULL CHECK (price >= 0),
    category    TEXT NOT NULL,
    image_path  TEXT NOT NULL DEFAULT '',
    is_active   INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS product_sizes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL REFERENCES products(id),
    size_eu    INTEGER NOT NULL,
    stock_qty  INTEGER NOT NULL DEFAULT 0 CHECK (stock_qty >= 0),
    UNIQUE (product_id, size_eu)
);
CREATE TABLE IF NOT EXISTS orders (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    buyer_id          INTEGER NOT NULL REFERENCES users(id),
    status            TEXT NOT NULL DEFAULT 'pending'
                      CHECK (status IN ('pending','shipped','delivered','cancelled')),
    total             INTEGER NOT NULL,
    delivery_fee      INTEGER NOT NULL DEFAULT 0,
    created_at        TEXT NOT NULL DEFAULT (datetime('now')),
    status_updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    shipping_name     TEXT NOT NULL,
    phone             TEXT NOT NULL,
    address           TEXT NOT NULL,
    payment_method    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS order_items (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id   INTEGER NOT NULL REFERENCES orders(id),
    product_id INTEGER NOT NULL REFERENCES products(id),
    size_eu    INTEGER NOT NULL,
    quantity   INTEGER NOT NULL CHECK (quantity > 0),
    unit_price INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS login_failures (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    email        TEXT NOT NULL,
    attempted_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_login_failures ON login_failures(email, attempted_at);
CREATE INDEX IF NOT EXISTS idx_products_seller ON products(seller_id);
CREATE INDEX IF NOT EXISTS idx_orders_buyer ON orders(buyer_id);
CREATE INDEX IF NOT EXISTS idx_items_order ON order_items(order_id);
"""


@contextmanager
def get_conn():
    """Yield a connection; commit on success, roll back on error.

    A new connection is opened per call so service functions can safely be run
    from worker threads (asyncio.to_thread) by the Flet UI handlers.
    """
    path = config.DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def begin_write(conn: sqlite3.Connection) -> None:
    """Start a transaction that holds the write lock, so concurrent writers are serialised."""
    conn.execute("BEGIN IMMEDIATE")


def init_db(seed: bool | None = None) -> None:
    """Create tables. Demo data is added only when asked (seed=True) or, if seed is
    None, when the environment allows it (SOLESTRIDE_SEED_DEMO; off in production)."""
    with get_conn() as conn:
        conn.executescript(SCHEMA)
    if config.SEED_DEMO if seed is None else seed:
        from .seed import seed_demo_data

        seed_demo_data()
