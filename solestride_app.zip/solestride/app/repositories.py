"""Data access layer (Phase 2, section 3.2).

Every SQL statement in the application lives here. Services receive a
connection and call these repositories; the UI never touches SQL.
Swapping SQLite for Postgres/MySQL later means changing this module only.
"""
from __future__ import annotations

import sqlite3
from typing import Optional

from .models import Order, OrderItem, Product, User


class UserRepository:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    @staticmethod
    def _to_user(row) -> User:
        return User(id=row["id"], name=row["name"], email=row["email"], role=row["role"])

    def create(self, name: str, email: str, password_hash: str, role: str) -> User:
        cur = self.conn.execute(
            "INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?,?)",
            (name, email, password_hash, role),
        )
        return User(id=cur.lastrowid, name=name, email=email, role=role)

    def get_by_email(self, email: str):
        """Return (User, password_hash) or None."""
        row = self.conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        return (self._to_user(row), row["password_hash"]) if row else None

    def count(self) -> int:
        return self.conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]


class LoginAttemptRepository:
    """Failed-login log used to throttle password guessing."""

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def recent_failures(self, email: str, minutes: int) -> int:
        return self.conn.execute(
            "SELECT COUNT(*) FROM login_failures WHERE email = ? AND attempted_at >= datetime('now', ?)",
            (email, f"-{int(minutes)} minutes"),
        ).fetchone()[0]

    def record_failure(self, email: str) -> None:
        self.conn.execute("INSERT INTO login_failures (email) VALUES (?)", (email,))
        self.conn.execute("DELETE FROM login_failures WHERE attempted_at < datetime('now', '-1 day')")

    def clear(self, email: str) -> None:
        self.conn.execute("DELETE FROM login_failures WHERE email = ?", (email,))


class ProductRepository:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def _hydrate(self, rows) -> list[Product]:
        products = [
            Product(
                id=r["id"], seller_id=r["seller_id"], name=r["name"], description=r["description"],
                price=r["price"], category=r["category"], image_path=r["image_path"],
                is_active=bool(r["is_active"]),
            )
            for r in rows
        ]
        if not products:
            return products
        by_id = {p.id: p for p in products}
        marks = ",".join("?" * len(by_id))
        for s in self.conn.execute(
            f"SELECT product_id, size_eu, stock_qty FROM product_sizes WHERE product_id IN ({marks})",
            list(by_id),
        ):
            by_id[s["product_id"]].sizes[s["size_eu"]] = s["stock_qty"]
        for p in products:
            p.sizes = dict(sorted(p.sizes.items()))
        return products

    def get(self, product_id: int) -> Optional[Product]:
        rows = self.conn.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchall()
        found = self._hydrate(rows)
        return found[0] if found else None

    def list(self, query: str = "", category: str = "", size: Optional[int] = None,
             seller_id: Optional[int] = None, include_inactive: bool = False) -> list[Product]:
        sql = "SELECT p.* FROM products p WHERE 1=1"
        args: list = []
        if not include_inactive:
            sql += " AND p.is_active = 1"
        if seller_id is not None:
            sql += " AND p.seller_id = ?"
            args.append(seller_id)
        if query:
            # escape LIKE wildcards so "%" and "_" are searched literally
            esc = query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            sql += " AND (p.name LIKE ? ESCAPE '\\' OR p.description LIKE ? ESCAPE '\\')"
            args += [f"%{esc}%", f"%{esc}%"]
        if category:
            sql += " AND p.category = ?"
            args.append(category)
        if size is not None:
            sql += " AND EXISTS (SELECT 1 FROM product_sizes s WHERE s.product_id = p.id AND s.size_eu = ? AND s.stock_qty > 0)"
            args.append(size)
        sql += " ORDER BY p.id"
        return self._hydrate(self.conn.execute(sql, args).fetchall())

    def insert(self, seller_id: int, name: str, description: str, price: int,
               category: str, image_path: str) -> int:
        cur = self.conn.execute(
            "INSERT INTO products (seller_id, name, description, price, category, image_path) VALUES (?,?,?,?,?,?)",
            (seller_id, name, description, price, category, image_path),
        )
        return cur.lastrowid

    def update(self, product_id: int, name: str, description: str, price: int,
               category: str, image_path: str) -> None:
        self.conn.execute(
            "UPDATE products SET name=?, description=?, price=?, category=?, image_path=? WHERE id=?",
            (name, description, price, category, image_path, product_id),
        )

    def set_active(self, product_id: int, active: bool) -> None:
        self.conn.execute("UPDATE products SET is_active=? WHERE id=?", (int(active), product_id))

    def set_size_stock(self, product_id: int, size_eu: int, stock_qty: int) -> None:
        self.conn.execute(
            "INSERT INTO product_sizes (product_id, size_eu, stock_qty) VALUES (?,?,?) "
            "ON CONFLICT(product_id, size_eu) DO UPDATE SET stock_qty = excluded.stock_qty",
            (product_id, size_eu, stock_qty),
        )

    def decrement_stock(self, product_id: int, size_eu: int, qty: int) -> bool:
        """Atomic guarded decrement: succeeds only if enough stock remains."""
        cur = self.conn.execute(
            "UPDATE product_sizes SET stock_qty = stock_qty - ? "
            "WHERE product_id = ? AND size_eu = ? AND stock_qty >= ?",
            (qty, product_id, size_eu, qty),
        )
        return cur.rowcount == 1

    def increment_stock(self, product_id: int, size_eu: int, qty: int) -> None:
        self.conn.execute(
            "UPDATE product_sizes SET stock_qty = stock_qty + ? WHERE product_id = ? AND size_eu = ?",
            (qty, product_id, size_eu),
        )


class OrderRepository:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def create(self, buyer_id: int, total: int, delivery_fee: int, shipping_name: str,
               phone: str, address: str, payment_method: str) -> int:
        cur = self.conn.execute(
            "INSERT INTO orders (buyer_id, total, delivery_fee, shipping_name, phone, address, payment_method) "
            "VALUES (?,?,?,?,?,?,?)",
            (buyer_id, total, delivery_fee, shipping_name, phone, address, payment_method),
        )
        return cur.lastrowid

    def add_item(self, order_id: int, product_id: int, size_eu: int, quantity: int, unit_price: int) -> None:
        self.conn.execute(
            "INSERT INTO order_items (order_id, product_id, size_eu, quantity, unit_price) VALUES (?,?,?,?,?)",
            (order_id, product_id, size_eu, quantity, unit_price),
        )

    def _hydrate(self, rows) -> list[Order]:
        orders = [
            Order(
                id=r["id"], buyer_id=r["buyer_id"], buyer_name=r["buyer_name"], status=r["status"],
                total=r["total"], delivery_fee=r["delivery_fee"], created_at=r["created_at"],
                status_updated_at=r["status_updated_at"], shipping_name=r["shipping_name"],
                phone=r["phone"], address=r["address"], payment_method=r["payment_method"],
            )
            for r in rows
        ]
        if not orders:
            return orders
        by_id = {o.id: o for o in orders}
        marks = ",".join("?" * len(by_id))
        for it in self.conn.execute(
            f"SELECT oi.*, p.name AS product_name FROM order_items oi "
            f"JOIN products p ON p.id = oi.product_id WHERE oi.order_id IN ({marks}) ORDER BY oi.id",
            list(by_id),
        ):
            by_id[it["order_id"]].items.append(
                OrderItem(product_id=it["product_id"], name=it["product_name"], size_eu=it["size_eu"],
                          quantity=it["quantity"], unit_price=it["unit_price"])
            )
        return orders

    _BASE = "SELECT o.*, u.name AS buyer_name FROM orders o JOIN users u ON u.id = o.buyer_id"

    def get(self, order_id: int) -> Optional[Order]:
        rows = self.conn.execute(self._BASE + " WHERE o.id = ?", (order_id,)).fetchall()
        found = self._hydrate(rows)
        return found[0] if found else None

    def list_for_buyer(self, buyer_id: int) -> list[Order]:
        rows = self.conn.execute(self._BASE + " WHERE o.buyer_id = ? ORDER BY o.id DESC", (buyer_id,)).fetchall()
        return self._hydrate(rows)

    def list_for_seller(self, seller_id: int) -> list[Order]:
        rows = self.conn.execute(
            self._BASE + " WHERE o.id IN (SELECT oi.order_id FROM order_items oi "
            "JOIN products p ON p.id = oi.product_id WHERE p.seller_id = ?) ORDER BY o.id DESC",
            (seller_id,),
        ).fetchall()
        return self._hydrate(rows)

    def seller_owns_order(self, seller_id: int, order_id: int) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM order_items oi JOIN products p ON p.id = oi.product_id "
            "WHERE oi.order_id = ? AND p.seller_id = ? LIMIT 1",
            (order_id, seller_id),
        ).fetchone()
        return row is not None

    def set_status(self, order_id: int, status: str) -> None:
        self.conn.execute(
            "UPDATE orders SET status = ?, status_updated_at = datetime('now') WHERE id = ?",
            (status, order_id),
        )
