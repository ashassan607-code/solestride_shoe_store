"""Central configuration for the SoleStride MVP."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
ASSETS_DIR = BASE_DIR / "assets"
DB_PATH = Path(os.getenv("SOLESTRIDE_DB", BASE_DIR / "data" / "solestride.db"))

APP_NAME = "SoleStride"
TAGLINE = "Footwear for every step"
CURRENCY = "\u20a6"          # Naira. Prices are stored as whole naira (integers).
DELIVERY_FEE = 3000           # flat delivery fee for the MVP
LOW_STOCK_THRESHOLD = 5       # pairs per size at or below which a size is "low"
SIZES = [39, 40, 41, 42, 43, 44, 45]  # EU sizes offered in the MVP
CATEGORIES = ["Sneakers", "Formal", "Sandals", "Boots"]

ROLE_BUYER = "buyer"
ROLE_SELLER = "seller"

ORDER_STATUSES = ["pending", "shipped", "delivered", "cancelled"]
# Forward-only state machine (Phase 2, section 2.2). Cancel allowed from pending only.
ORDER_TRANSITIONS = {
    "pending": ["shipped", "cancelled"],
    "shipped": ["delivered"],
    "delivered": [],
    "cancelled": [],
}
PAYMENT_METHODS = {"card_transfer": "Card / Transfer", "pay_on_delivery": "Pay on Delivery"}

PASSWORD_MIN_LENGTH = 8
PBKDF2_ITERATIONS = 200_000

# Input limits (added after alpha testing, defects D-01 to D-04)
MAX_NAME_LEN = 100
MAX_EMAIL_LEN = 254
MAX_PASSWORD_LEN = 128
MAX_DESCRIPTION_LEN = 1000
MAX_ADDRESS_LEN = 300
MAX_PRICE = 10_000_000        # naira per pair
MAX_STOCK_PER_SIZE = 10_000


# ---- Deployment / environment (Phase 5) ------------------------------------
# SOLESTRIDE_ENV=production switches the safe defaults on: no demo data, no demo
# login hint, and seller accounts can only be created by the owner (manage.py).
ENV = os.getenv("SOLESTRIDE_ENV", "development").lower()
IS_PRODUCTION = ENV == "production"


def _flag(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    return default if raw is None else raw.strip().lower() in ("1", "true", "yes", "on")


SEED_DEMO = _flag("SOLESTRIDE_SEED_DEMO", not IS_PRODUCTION)
ALLOW_SELLER_SIGNUP = _flag("SOLESTRIDE_ALLOW_SELLER_SIGNUP", not IS_PRODUCTION)

# Login throttling (closes risk R-01 from Phase 4)
LOGIN_MAX_FAILURES = 5
LOGIN_LOCKOUT_MINUTES = 15
