# Deploying SoleStride (Docker on a VPS)

Requirements: a Linux server with Docker + Docker Compose, ports 80 and 443 open,
and a domain name whose A record points at the server's IP address.

```bash
git clone https://github.com/<your-user>/solestride.git && cd solestride
cp .env.example .env && nano .env            # set DOMAIN=your.domain
docker compose up -d --build                 # build image, start app + HTTPS proxy
docker compose ps                            # app should become "healthy"
docker compose exec app python manage.py create-seller --name "Store Owner" --email owner@your.domain
```

Open `https://your.domain`, log in as the owner and add shoes. Production mode has no demo
accounts, hides the demo login hint, and only the owner command above can create sellers.

## Operating it
| Task | Command |
|------|---------|
| Logs | `docker compose logs -f app` |
| Update to a new version | `git pull && docker compose up -d --build` |
| Back up the database | `docker compose exec app python manage.py backup --to /data/backups` |
| Copy a backup off the server | `docker compose cp app:/data/backups ./backups` |
| Stop | `docker compose down` (data volume is kept) |

## Roll back
`git checkout <previous-tag> && docker compose up -d --build`. To restore data, stop the
app and copy a backup file over `/data/solestride.db` inside the volume.

## Without a domain (quick test only)
Change the first line of `Caddyfile` to `:80`, then browse to `http://<server-ip>`.
Do not take real orders or passwords over plain HTTP.
